import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Room, formatKES } from "@/lib/roomData";
import { supabase } from "@/integrations/supabase/client";
import { useRecordPayment, paymentSchema, PaymentFormValues } from "@/hooks/useRecordPayment";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, CreditCard } from "lucide-react";

interface PaymentFormProps {
  room: Room;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ActiveLease {
  id: string;
  tenant_id: string;
  monthly_rent: number;
}

export function PaymentForm({ room, open, onOpenChange }: PaymentFormProps) {
  const [activeLease, setActiveLease] = useState<ActiveLease | null>(null);
  const [leaseLoading, setLeaseLoading] = useState(false);
  const [leaseError, setLeaseError] = useState<string | null>(null);
  const recordPayment = useRecordPayment();

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    watch,
    formState: { errors },
  } = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      payment_method: "equity_mtaani_pdq",
      payment_date: new Date().toISOString().slice(0, 10),
    },
  });

  // Fetch the active lease for this room
  useEffect(() => {
    if (!open) return;
    setLeaseError(null);
    setActiveLease(null);
    setLeaseLoading(true);
    supabase
      .from("leases")
      .select("id, tenant_id, monthly_rent")
      .eq("room_id", room.id)
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .limit(1)
      .single()
      .then(({ data, error }) => {
        if (error || !data) {
          setLeaseError("No active lease found for this room.");
        } else {
          setActiveLease(data);
        }
        setLeaseLoading(false);
      });
  }, [open, room.id]);

  const balance = room.amountDue - room.amountPaid;
  const watchedAmount = watch("amount");
  const parsedAmount = Number(watchedAmount) || 0;
  const newPaid = room.amountPaid + parsedAmount;
  const newBalance = room.amountDue - newPaid;

  const onSubmit = async (values: PaymentFormValues) => {
    if (!activeLease) return;
    await recordPayment.mutateAsync({
      roomId: room.id,
      leaseId: activeLease.id,
      tenantId: activeLease.tenant_id,
      values,
      currentAmountPaid: room.amountPaid,
      amountDue: room.amountDue,
    });
    reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[420px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-mono">
            <CreditCard className="h-4 w-4 text-primary" />
            Record Payment — Room {room.number}
          </DialogTitle>
        </DialogHeader>

        {/* Room financial summary */}
        <div className="grid grid-cols-3 gap-2 rounded-md bg-muted/50 p-3 text-center text-xs font-mono">
          <div>
            <p className="text-muted-foreground">Due</p>
            <p className="font-semibold text-foreground">{formatKES(room.amountDue)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Paid</p>
            <p className="font-semibold text-foreground">{formatKES(room.amountPaid)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Balance</p>
            <p className={`font-semibold ${balance > 0 ? "text-destructive" : "text-primary"}`}>
              {formatKES(balance)}
            </p>
          </div>
        </div>

        {leaseLoading && (
          <div className="flex items-center justify-center py-4 gap-2 text-muted-foreground text-sm">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading lease…
          </div>
        )}

        {leaseError && !leaseLoading && (
          <p className="text-sm text-destructive text-center py-2">{leaseError}</p>
        )}

        {activeLease && !leaseLoading && (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            {/* Amount */}
            <div className="space-y-1.5">
              <Label htmlFor="amount">Amount (KES)</Label>
              <Input
                id="amount"
                type="number"
                min="1"
                step="0.01"
                placeholder={`e.g. ${formatKES(balance > 0 ? balance : activeLease.monthly_rent)}`}
                className="font-mono"
                {...register("amount")}
              />
              {errors.amount && (
                <p className="text-xs text-destructive">{errors.amount.message}</p>
              )}
              {parsedAmount > 0 && (
                <p className={`text-xs font-mono ${newBalance <= 0 ? "text-primary" : "text-muted-foreground"}`}>
                  New balance: {formatKES(Math.abs(newBalance))}{" "}
                  {newBalance < 0 ? "(advance)" : newBalance === 0 ? "✓ cleared" : "remaining"}
                </p>
              )}
            </div>

            {/* Payment method */}
            <div className="space-y-1.5">
              <Label>Payment Method</Label>
              <Input
                value="Equity Mtaani-PDQ"
                disabled
                className="font-mono bg-muted"
              />
            </div>

            {/* Reference number */}
            <div className="space-y-1.5">
              <Label htmlFor="reference_number">Reference / Transaction No. <span className="text-muted-foreground">(optional)</span></Label>
              <Input
                id="reference_number"
                placeholder="e.g. QA12BC45DE"
                className="font-mono"
                {...register("reference_number")}
              />
              {errors.reference_number && (
                <p className="text-xs text-destructive">{errors.reference_number.message}</p>
              )}
            </div>

            {/* Payment date */}
            <div className="space-y-1.5">
              <Label htmlFor="payment_date">Payment Date</Label>
              <Input
                id="payment_date"
                type="date"
                className="font-mono"
                {...register("payment_date")}
              />
              {errors.payment_date && (
                <p className="text-xs text-destructive">{errors.payment_date.message}</p>
              )}
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={recordPayment.isPending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={recordPayment.isPending}>
                {recordPayment.isPending ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Saving…</>
                ) : (
                  "Record Payment"
                )}
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
