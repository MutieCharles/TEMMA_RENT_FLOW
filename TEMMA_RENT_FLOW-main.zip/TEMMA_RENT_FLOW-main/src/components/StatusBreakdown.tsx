import { motion } from "framer-motion";
import { Room, RoomStatus, statusConfig, formatKES } from "@/lib/roomData";

interface StatusBreakdownProps {
  rooms: Room[];
}

export function StatusBreakdown({ rooms }: StatusBreakdownProps) {
  const total = rooms.length;
  const counts = (Object.keys(statusConfig) as RoomStatus[]).map((status) => {
    const matching = rooms.filter((r) => r.status === status);
    const revenue = matching.reduce((s, r) => s + r.amountPaid, 0);
    return {
      status,
      count: matching.length,
      pct: Math.round((matching.length / total) * 100),
      revenue,
      ...statusConfig[status],
    };
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="rounded-lg border border-border bg-card p-5"
    >
      <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">
        Status Breakdown
      </h3>

      {/* Bar */}
      <div className="flex h-3 rounded-full overflow-hidden mb-4">
        {counts.map((c) => (
          <motion.div
            key={c.status}
            initial={{ width: 0 }}
            animate={{ width: `${c.pct}%` }}
            transition={{ delay: 0.6, duration: 0.6 }}
            className={`${c.colorClass}`}
          />
        ))}
      </div>

      <div className="space-y-2">
        {counts.map((c) => (
          <div key={c.status} className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <div className={`w-2.5 h-2.5 rounded-sm ${c.colorClass}`} />
              <span className="text-muted-foreground">{c.label}</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="font-mono text-foreground">{c.count} <span className="text-muted-foreground">({c.pct}%)</span></span>
              <span className="font-mono text-muted-foreground w-28 text-right">{formatKES(c.revenue)}</span>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
