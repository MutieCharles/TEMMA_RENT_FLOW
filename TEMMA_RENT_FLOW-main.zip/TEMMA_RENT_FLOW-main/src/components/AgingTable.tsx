import { motion } from "framer-motion";
import { Room, getAgingBucket, formatKES } from "@/lib/roomData";

interface AgingTableProps {
  rooms: Room[];
}

export function AgingTable({ rooms }: AgingTableProps) {
  const overdueRooms = rooms.filter((r) => r.status === 'overdue' || r.status === 'exception');
  
  const buckets = {
    '0–30': overdueRooms.filter((r) => getAgingBucket(r.agingDays) === '0–30'),
    '30–60': overdueRooms.filter((r) => getAgingBucket(r.agingDays) === '30–60'),
    '60+': overdueRooms.filter((r) => getAgingBucket(r.agingDays) === '60+'),
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="rounded-lg border border-border bg-card p-5"
    >
      <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">
        Aging Buckets
      </h3>
      <div className="grid grid-cols-3 gap-3">
        {Object.entries(buckets).map(([bucket, bRooms]) => {
          const total = bRooms.reduce((s, r) => s + (r.amountDue - r.amountPaid), 0);
          const isHigh = bucket === '60+';
          return (
            <div
              key={bucket}
              className={`rounded-md p-4 border ${isHigh ? 'border-status-overdue/40 bg-status-overdue/5' : 'border-border bg-secondary/30'}`}
            >
              <p className="text-xs text-muted-foreground mb-1">{bucket} days</p>
              <p className={`text-xl font-bold font-mono ${isHigh ? 'text-status-overdue' : 'text-foreground'}`}>
                {formatKES(total)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">{bRooms.length} rooms</p>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}
