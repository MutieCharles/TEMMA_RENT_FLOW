import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Room, statusConfig, formatKES, toBillNumber } from "@/lib/roomData";
import { Button } from "@/components/ui/button";
import { CreditCard, Clock, Banknote } from "lucide-react";
import { PaymentForm } from "@/components/PaymentForm";
import { useRoomPayments } from "@/hooks/usePayments";
import { format } from "date-fns";

interface RoomDetailProps {
  room: Room | null;
}

const METHOD_LABELS: Record<string, string> = {
  equity_mtaani_pdq: "Equity Mtaani-PDQ",
  mpesa: "M-Pesa",
  cash: "Cash",
  bank_transfer: "Bank",
  cheque: "Cheque",
};

export function RoomDetail({ room }: RoomDetailProps) {
  const [paymentOpen, setPaymentOpen] = useState(false);
  const { data: payments = [], isLoading: paymentsLoading } = useRoomPayments(room?.id ?? null);

  return (
    <div className="rounded-lg border border-border bg-card p-5 min-h-[200px]">
      <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">
        Room Detail
      </h3>
      <AnimatePresence mode="wait">
        {room ? (
          <motion.div
            key={room.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-3"
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">{statusConfig[room.status].emoji}</span>
              <div>
                <p className="text-lg font-bold font-mono text-foreground">{room.roomType === 'shop' ? 'Shop' : 'Room'} {room.number}</p>
                <p className="text-sm text-muted-foreground">{statusConfig[room.status].label} — Block {room.block} · KES {room.roomType === 'shop' ? '7,500' : '4,500'}/mo</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 rounded-md bg-muted/60 px-2.5 py-1 w-fit">
              <Banknote className="h-3 w-3 text-primary" />
              <span className="text-[11px] font-mono font-semibold text-foreground">
                Bill No: {toBillNumber(room.number, room.block)}
              </span>
            </div>
            {room.guest && <Row label="Tenant" value={room.guest} />}
            <Row label="Amount Due" value={formatKES(room.amountDue)} />
            <Row label="Amount Paid" value={formatKES(room.amountPaid)} />
            <Row
              label="Balance"
              value={formatKES(room.amountDue - room.amountPaid)}
              highlight={room.amountDue - room.amountPaid > 0}
            />
            {room.agingDays > 0 && (
              <Row label="Aging" value={`${room.agingDays} days`} highlight />
            )}

            {room.status !== "vacant" && (
              <Button
                size="sm"
                className="w-full mt-2"
                onClick={() => setPaymentOpen(true)}
              >
                <CreditCard className="h-3.5 w-3.5" />
                Record Payment
              </Button>
            )}

            {/* Payment History */}
            <div className="pt-2 border-t border-border">
              <div className="flex items-center gap-1.5 mb-2">
                <Clock className="h-3 w-3 text-muted-foreground" />
                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Recent Payments
                </span>
              </div>

              {paymentsLoading ? (
                <div className="space-y-1.5">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-9 rounded-md bg-muted/50 animate-pulse" />
                  ))}
                </div>
              ) : payments.length === 0 ? (
                <p className="text-xs text-muted-foreground italic py-1">No payments recorded yet.</p>
              ) : (
                <div className="space-y-1.5">
                  {payments.map((p) => (
                    <motion.div
                      key={p.id}
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center justify-between rounded-md bg-muted/40 px-2.5 py-1.5 gap-2"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        <Banknote className="h-3 w-3 text-primary shrink-0" />
                        <div className="min-w-0">
                          <p className="text-xs font-mono font-semibold text-foreground">
                            {formatKES(Number(p.amount))}
                          </p>
                          <p className="text-[10px] text-muted-foreground truncate">
                            {p.reference_number ? `Ref: ${p.reference_number}` : (METHOD_LABELS[p.payment_method ?? ""] ?? p.payment_method ?? "—")}
                          </p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="inline-block text-[10px] font-mono bg-primary/10 text-primary rounded px-1.5 py-0.5">
                          {METHOD_LABELS[p.payment_method ?? ""] ?? p.payment_method ?? "—"}
                        </span>
                        <p className="text-[10px] text-muted-foreground mt-0.5">
                          {format(new Date(p.payment_date), "dd MMM yy")}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-sm text-muted-foreground italic"
          >
            Select a room to view details
          </motion.p>
        )}
      </AnimatePresence>

      {room && (
        <PaymentForm
          room={room}
          open={paymentOpen}
          onOpenChange={setPaymentOpen}
        />
      )}
    </div>
  );
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`text-sm font-mono font-semibold ${highlight ? 'text-status-overdue' : 'text-foreground'}`}>
        {value}
      </span>
    </div>
  );
}
