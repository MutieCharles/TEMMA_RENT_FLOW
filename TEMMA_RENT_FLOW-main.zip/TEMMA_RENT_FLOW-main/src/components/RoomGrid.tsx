import { useState, useMemo, useRef } from "react";
import { Room, statusConfig, RoomStatus, formatKES } from "@/lib/roomData";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Input } from "@/components/ui/input";
import { useBlocks } from "@/hooks/useBlocks";
import { Search, X } from "lucide-react";

interface RoomGridProps {
  rooms: Room[];
  selectedRoom: Room | null;
  onSelect: (room: Room) => void;
}

export function RoomGrid({ rooms, selectedRoom, onSelect }: RoomGridProps) {
  const { data: dbBlocks } = useBlocks();
  const blockCodes = useMemo(() => (dbBlocks ?? []).map((b) => b.code).sort(), [dbBlocks]);
  const [activeBlock, setActiveBlock] = useState<string>("");
  const [search, setSearch] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  // Search: find matching rooms across all blocks
  const searchResults = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return [];
    return rooms.filter((r) => r.number.toLowerCase().includes(q)).slice(0, 12);
  }, [search, rooms]);

  const handleSearchSelect = (room: Room) => {
    setActiveBlock(room.block);
    onSelect(room);
    setSearch("");
    inputRef.current?.blur();
  };

  const currentBlock = activeBlock || blockCodes[0] || "A";
  const blockRooms = rooms.filter((r) => r.block === currentBlock);
  const blockInfo = dbBlocks?.find((b) => b.code === currentBlock);
  const maxFloor = blockRooms.reduce((m, r) => Math.max(m, r.floor), 0);
  const floors = Array.from({ length: maxFloor }, (_, i) => maxFloor - i);

  // Build room range label e.g. "RM E1...E350" or "RM 1...74" for Block H
  const blockRangeLabel = useMemo(() => {
    if (blockRooms.length === 0) return "";
    const nums = blockRooms
      .map((r) => parseInt(r.number.replace(/\D/g, ""), 10))
      .filter((n) => !isNaN(n));
    if (nums.length === 0) return "";
    const min = Math.min(...nums);
    const max = Math.max(...nums);
    const isBlockH = currentBlock === "H";
    return isBlockH
      ? `RM ${min}...${max}`
      : `RM ${currentBlock}${min}...${currentBlock}${max}`;
  }, [blockRooms, currentBlock]);

  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-center justify-between mb-4 gap-3">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider shrink-0">
          Operational Matrix — {rooms.length.toLocaleString()} Rooms
        </h3>
        {/* Search input */}
        <div className="relative w-48">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
          <Input
            ref={inputRef}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search room…"
            className="h-7 pl-7 pr-7 text-xs font-mono"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="h-3 w-3" />
            </button>
          )}
          {/* Dropdown results */}
          {searchResults.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 z-50 rounded-md border border-border bg-popover shadow-lg overflow-hidden">
              {searchResults.map((room) => {
                const cfg = statusConfig[room.status];
                return (
                  <button
                    key={room.id}
                    onClick={() => handleSearchSelect(room)}
                    className="w-full flex items-center gap-2 px-3 py-1.5 text-left hover:bg-accent transition-colors"
                  >
                    <div className={`w-2 h-2 rounded-sm shrink-0 ${cfg.colorClass}`} />
                    <span className="text-xs font-mono font-semibold text-foreground">{room.number}</span>
                    <span className="text-[10px] text-muted-foreground ml-auto">Blk {room.block}</span>
                    <span className="text-[10px] text-muted-foreground">{cfg.label}</span>
                  </button>
                );
              })}
              {search.trim() && rooms.filter(r => r.number.toLowerCase().includes(search.trim().toLowerCase())).length > 12 && (
                <p className="text-[10px] text-muted-foreground text-center py-1">…more results, refine search</p>
              )}
            </div>
          )}
          {search.trim() && searchResults.length === 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 z-50 rounded-md border border-border bg-popover shadow-lg px-3 py-2">
              <p className="text-xs text-muted-foreground font-mono">No rooms found</p>
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-4">
      {blockCodes.map((code) => {
          const bRooms = rooms.filter((r) => r.block === code);
          const overdueRooms = bRooms.filter((r) => r.status === "overdue");
          const overdueCount = overdueRooms.length;
          const amountAtRisk = overdueRooms.reduce((s, r) => s + (r.amountDue - r.amountPaid), 0);
          const occupied = bRooms.filter((r) => r.status !== "vacant").length;
          const occupancyPct = bRooms.length > 0 ? Math.round((occupied / bRooms.length) * 100) : 0;
          const totalRevenue = bRooms.reduce((s, r) => s + r.amountPaid, 0);
          const isActive = currentBlock === code;
          return (
            <Tooltip key={code}>
              <TooltipTrigger asChild>
                <button
                  onClick={() => setActiveBlock(code)}
                  className={`flex flex-col items-start px-3 py-1.5 rounded-md text-xs font-mono font-semibold transition-all ${
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                >
                  <span>{code}</span>
                  {overdueCount > 0 && (
                    <span className={`text-[9px] font-mono font-normal mt-0.5 ${isActive ? "text-primary-foreground/70" : "text-destructive"}`}>
                      {overdueCount}⚠ {amountAtRisk >= 1000 ? `${(amountAtRisk / 1000).toFixed(0)}k` : amountAtRisk.toFixed(0)}
                    </span>
                  )}
                </button>
              </TooltipTrigger>
              <TooltipContent className="bg-card border-border text-foreground p-3 space-y-1.5 min-w-[160px]">
                <p className="font-mono font-semibold text-xs mb-2">Block {code} · {bRooms.length} rooms</p>
                <div className="flex justify-between text-[11px]">
                  <span className="text-muted-foreground">Occupancy</span>
                  <span className="font-semibold">{occupancyPct}% <span className="text-muted-foreground font-normal">({occupied}/{bRooms.length})</span></span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-muted-foreground">Revenue</span>
                  <span className="font-semibold">{formatKES(totalRevenue)}</span>
                </div>
                {overdueCount > 0 && (
                  <div className="flex justify-between text-[11px]">
                    <span className="text-muted-foreground">Overdue</span>
                    <span className="font-semibold text-destructive">{overdueCount} · {formatKES(amountAtRisk)}</span>
                  </div>
                )}
              </TooltipContent>
            </Tooltip>
          );
        })}
      </div>

      <p className="text-xs text-muted-foreground mb-3 font-mono">
        Block {currentBlock}: {blockRooms.length.toLocaleString()} rooms ({blockRangeLabel})
      </p>

      <div className="space-y-1.5 overflow-x-auto">
        {floors.map((floor) => (
          <div key={floor} className="flex items-center gap-1.5">
            <span className="text-[10px] font-mono text-muted-foreground w-5 shrink-0">{floor === 1 ? 'GF' : `F${floor}`}</span>
            <div className="flex gap-1 flex-wrap">
              {blockRooms
                .filter((r) => r.floor === floor)
                .sort((a, b) => {
                  const aNum = parseInt(a.number.replace(/\D/g, ''), 10) || 0;
                  const bNum = parseInt(b.number.replace(/\D/g, ''), 10) || 0;
                  return aNum - bNum;
                })
                .map((room) => {
                  const cfg = statusConfig[room.status];
                  const isSelected = selectedRoom?.id === room.id;
                  return (
                    <Tooltip key={room.id}>
                      <TooltipTrigger asChild>
                        <button
                          onClick={() => onSelect(room)}
                          className={`${room.roomType === 'shop' ? 'min-w-[3.2rem] px-1 h-7 border border-amber-400/60' : 'w-7 h-7'} rounded text-[9px] font-mono font-semibold flex items-center justify-center cursor-pointer transition-all duration-150 ${cfg.colorClass} ${
                            isSelected ? "ring-2 ring-foreground scale-125 z-10" : "hover:scale-110"
                          } ${room.status === "vacant" ? "text-muted-foreground" : "text-primary-foreground"}`}
                        >
                          {room.roomType === 'shop' ? `🏪${room.number}` : room.number.replace(/^RM\s*[A-H]?/, '').slice(-3)}
                        </button>
                      </TooltipTrigger>
                      <TooltipContent className="bg-card border-border">
                        <p className="font-mono text-xs">
                          {cfg.emoji} {room.number} — {cfg.label}
                          {room.guest && <><br />{room.guest}</>}
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  );
                })}
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-3 mt-5 pt-4 border-t border-border">
        {Object.entries(statusConfig).map(([key, cfg]) => (
          <div key={key} className="flex items-center gap-1.5">
            <div className={`w-3 h-3 rounded-sm ${cfg.colorClass}`} />
            <span className="text-xs text-muted-foreground">{cfg.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
