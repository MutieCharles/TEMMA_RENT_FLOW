import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { z } from "zod";

export const paymentSchema = z.object({
  amount: z
    .string()
    .trim()
    .nonempty("Amount is required")
    .refine((v) => !isNaN(Number(v)) && Number(v) > 0, "Must be a positive number"),
  payment_method: z.enum(["equity_mtaani_pdq"]),
  reference_number: z.string().trim().max(100).optional(),
  payment_date: z.string().nonempty("Date is required"),
});

export type PaymentFormValues = z.infer<typeof paymentSchema>;

interface RecordPaymentInput {
  roomId: string;
  leaseId: string;
  tenantId: string;
  values: PaymentFormValues;
  currentAmountPaid: number;
  amountDue: number;
}

export function useRecordPayment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({
      roomId,
      leaseId,
      tenantId,
      values,
      currentAmountPaid,
      amountDue,
    }: RecordPaymentInput) => {
      const amount = Number(values.amount);
      const newAmountPaid = currentAmountPaid + amount;

      // Determine new room status
      let newStatus: string;
      if (newAmountPaid <= 0) {
        newStatus = "overdue";
      } else if (newAmountPaid >= amountDue) {
        newStatus = newAmountPaid > amountDue ? "advance" : "paid";
      } else {
        newStatus = "partial";
      }

      // Insert payment record
      const { data: payment, error: paymentError } = await supabase
        .from("payments")
        .insert({
          room_id: roomId,
          lease_id: leaseId,
          tenant_id: tenantId,
          amount,
          payment_method: values.payment_method,
          reference_number: values.reference_number || null,
          payment_date: new Date(values.payment_date).toISOString(),
          reconciled: false,
        })
        .select()
        .single();

      if (paymentError) throw paymentError;

      // Update room financials and status
      const { error: roomError } = await supabase
        .from("rooms")
        .update({
          amount_paid: newAmountPaid,
          status: newStatus as never,
          aging_days: newAmountPaid >= amountDue ? 0 : undefined,
        })
        .eq("id", roomId);

      if (roomError) throw roomError;

      // Audit log
      await supabase.from("audit_logs").insert({
        action: "payment_recorded",
        entity_type: "payment",
        entity_id: payment.id,
        details: { room_id: roomId, amount, payment_method: values.payment_method, new_status: newStatus },
      });

      return payment;
    },
    onSuccess: (_, { roomId }) => {
      qc.invalidateQueries({ queryKey: ["rooms"] });
      qc.invalidateQueries({ queryKey: ["payments"] });
      qc.invalidateQueries({ queryKey: ["payments", roomId] });
      toast.success("Payment recorded successfully");
    },
    onError: (e: Error) => toast.error(`Failed to record payment: ${e.message}`),
  });
}
