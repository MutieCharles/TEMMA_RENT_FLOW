import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";
import { format, startOfMonth } from "date-fns";

export interface MonthlyStatusRow {
  id: string;
  room_id: string;
  month: string;
  expected_rent: number;
  total_paid: number;
  status: string;
  advance_credit_carried_forward: number;
}

/**
 * Fetch monthly_status_summary rows for a given month (YYYY-MM-DD of month start).
 * For past/closed months this returns snapshot data.
 */
export function useMonthlyStatus(month: Date) {
  const qc = useQueryClient();
  const monthKey = format(startOfMonth(month), "yyyy-MM-dd");

  useEffect(() => {
    const channel = supabase
      .channel(`monthly-status-${monthKey}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "monthly_status_summary" },
        () => {
          qc.invalidateQueries({ queryKey: ["monthly_status", monthKey] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc, monthKey]);

  return useQuery({
    queryKey: ["monthly_status", monthKey],
    queryFn: async (): Promise<MonthlyStatusRow[]> => {
      const { data, error } = await supabase
        .from("monthly_status_summary")
        .select("*")
        .eq("month", monthKey);
      if (error) throw error;
      return (data ?? []) as MonthlyStatusRow[];
    },
    staleTime: 30000,
  });
}
