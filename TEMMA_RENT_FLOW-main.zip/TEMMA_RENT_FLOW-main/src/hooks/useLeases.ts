import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Tables, TablesInsert } from "@/integrations/supabase/types";
import { toast } from "sonner";

export type Lease = Tables<"leases"> & { tenants?: Tables<"tenants"> | null; rooms?: Tables<"rooms"> | null };

export function useLeases() {
  return useQuery({
    queryKey: ["leases"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("leases")
        .select("*, tenants(*), rooms(*)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Lease[];
    },
  });
}

export function useCreateLease() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (lease: TablesInsert<"leases">) => {
      const { data, error } = await supabase.from("leases").insert(lease).select().single();
      if (error) throw error;
      await supabase.from("audit_logs").insert({
        action: "lease_created",
        entity_type: "lease",
        entity_id: data.id,
        details: { tenant_id: data.tenant_id, room_id: data.room_id },
      });
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leases"] });
      toast.success("Lease created successfully");
    },
    onError: (e) => toast.error(`Failed: ${e.message}`),
  });
}
