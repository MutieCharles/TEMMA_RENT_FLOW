import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format, startOfMonth } from "date-fns";

/**
 * Close the current billing month:
 * 1. Snapshot every occupied room into monthly_status_summary
 * 2. Carry forward advance credits to next month
 * 3. Reset rooms for the new billing period
 */
export function useCloseMonth() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      const monthKey = format(startOfMonth(new Date()), "yyyy-MM-dd");

      // 1. Fetch all occupied rooms
      const { data: rooms, error: roomsErr } = await supabase
        .from("rooms")
        .select("id, amount_due, amount_paid, status, room_type")
        .neq("status", "vacant");

      if (roomsErr) throw roomsErr;
      if (!rooms || rooms.length === 0) throw new Error("No occupied rooms to close");

      // 2. Build snapshot rows
      const snapshots = rooms.map((r) => {
        const due = Number(r.amount_due);
        const paid = Number(r.amount_paid);
        const advance = Math.max(0, paid - due);
        return {
          room_id: r.id,
          month: monthKey,
          expected_rent: due,
          total_paid: paid,
          status: r.status,
          advance_credit_carried_forward: advance,
        };
      });

      // 3. Upsert snapshots (idempotent on room_id+month unique)
      const { error: snapErr } = await supabase
        .from("monthly_status_summary")
        .upsert(snapshots, { onConflict: "room_id,month" });

      if (snapErr) throw snapErr;

      // 4. Reset rooms for new period (apply advance credits)
      const now = new Date().toISOString();
      let updatedCount = 0;

      for (const r of rooms) {
        const due = Number(r.amount_due);
        const paid = Number(r.amount_paid);
        const advanceCredit = Math.max(0, paid - due);
        const newDue = r.room_type === "shop" ? 7500 : 4500;

        // Carry forward: if tenant overpaid, apply credit to new month
        const newPaid = advanceCredit;
        let newStatus: string;
        if (newPaid >= newDue) {
          newStatus = newPaid > newDue ? "advance" : "paid";
        } else if (newPaid > 0) {
          newStatus = "partial";
        } else {
          newStatus = "overdue";
        }

        const { error } = await supabase
          .from("rooms")
          .update({
            amount_due: newDue,
            amount_paid: newPaid,
            aging_days: 0,
            status: newStatus as "advance" | "overdue" | "paid" | "partial",
            updated_at: now,
          })
          .eq("id", r.id);

        if (error) throw error;
        updatedCount++;
      }

      // 5. Audit log
      await supabase.from("audit_logs").insert({
        action: "billing_period_closed",
        entity_type: "billing_period",
        details: {
          month: monthKey,
          rooms_snapshotted: snapshots.length,
          advance_credits_carried: snapshots.filter(
            (s) => s.advance_credit_carried_forward > 0
          ).length,
        },
      });

      return { snapshotted: snapshots.length, updated: updatedCount, month: monthKey };
    },
    onSuccess: (result) => {
      qc.invalidateQueries({ queryKey: ["rooms"] });
      qc.invalidateQueries({ queryKey: ["monthly_status"] });
      toast.success(
        `Closed ${format(new Date(result.month), "MMM yyyy")}: ${result.snapshotted} units snapshotted, advance credits carried forward`
      );
    },
    onError: (e: Error) => {
      toast.error(`Failed to close month: ${e.message}`);
    },
  });
}
