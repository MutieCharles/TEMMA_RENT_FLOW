import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Tables } from "@/integrations/supabase/types";

export type PaymentRow = Tables<"payments"> & {
  rooms: (Tables<"rooms"> & { blocks: Tables<"blocks"> | null }) | null;
  tenants: Tables<"tenants"> | null;
};

export interface PaymentsFilter {
  blockId: string | null;
  paymentMethod: string | null;
  dateFrom: string | null;
  dateTo: string | null;
  reconciled: "all" | "reconciled" | "unreconciled";
  page: number;
  pageSize: number;
}

const PAGE_SIZE = 20;

export function usePaymentsTable(filter: PaymentsFilter) {
  return useQuery({
    queryKey: ["payments_table", filter],
    queryFn: async () => {
      let query = supabase
        .from("payments")
        .select("*, rooms(*, blocks(*)), tenants(*)", { count: "exact" })
        .order("payment_date", { ascending: false });

      if (filter.blockId) {
        // filter by block via rooms
        query = query.eq("rooms.block_id", filter.blockId);
      }
      if (filter.paymentMethod) {
        query = query.eq("payment_method", filter.paymentMethod);
      }
      if (filter.dateFrom) {
        query = query.gte("payment_date", filter.dateFrom);
      }
      if (filter.dateTo) {
        // include the full day
        const to = new Date(filter.dateTo);
        to.setHours(23, 59, 59, 999);
        query = query.lte("payment_date", to.toISOString());
      }
      if (filter.reconciled === "reconciled") {
        query = query.eq("reconciled", true);
      } else if (filter.reconciled === "unreconciled") {
        query = query.eq("reconciled", false);
      }

      const from = (filter.page - 1) * filter.pageSize;
      const to = from + filter.pageSize - 1;
      query = query.range(from, to);

      const { data, error, count } = await query;
      if (error) throw error;
      return { data: data as PaymentRow[], count: count ?? 0 };
    },
    staleTime: 10000,
    refetchInterval: 30000,
  });
}

export const PAYMENT_METHODS = [
  { value: "equity_mtaani_pdq", label: "Equity Mtaani-PDQ" },
];

export { PAGE_SIZE };
