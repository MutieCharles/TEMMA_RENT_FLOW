import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Tables } from "@/integrations/supabase/types";

export type Block = Tables<"blocks">;

export function useBlocks() {
  return useQuery({
    queryKey: ["blocks"],
    queryFn: async () => {
      const { data, error } = await supabase.from("blocks").select("*").order("code");
      if (error) throw error;
      return data as Block[];
    },
  });
}
