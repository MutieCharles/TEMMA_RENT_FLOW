import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Tables } from "@/integrations/supabase/types";
import { useEffect } from "react";

export type DbRoom = Tables<"rooms"> & { blocks?: Tables<"blocks"> | null };

const CACHE_KEY = "rooms_cache";
const CACHE_TIMESTAMP_KEY = "rooms_cache_ts";

function getCachedRooms(): DbRoom[] | null {
  try {
    const cached = localStorage.getItem(CACHE_KEY);
    const ts = localStorage.getItem(CACHE_TIMESTAMP_KEY);
    if (cached && ts) {
      const age = Date.now() - Number(ts);
      if (age < 1000 * 60 * 60) return JSON.parse(cached);
    }
  } catch {}
  return null;
}

function setCachedRooms(rooms: DbRoom[]) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(rooms));
    localStorage.setItem(CACHE_TIMESTAMP_KEY, String(Date.now()));
  } catch {}
}

async function fetchRooms(): Promise<DbRoom[]> {
  const PAGE_SIZE = 1000;
  let allRooms: DbRoom[] = [];
  let from = 0;

  while (true) {
    const { data, error } = await supabase
      .from("rooms")
      .select("*, blocks(*)")
      .order("number")
      .range(from, from + PAGE_SIZE - 1);
    if (error) throw error;
    const page = (data || []) as DbRoom[];
    allRooms = allRooms.concat(page);
    if (page.length < PAGE_SIZE) break;
    from += PAGE_SIZE;
  }

  setCachedRooms(allRooms);
  return allRooms;
}

export function useRooms(autoRefresh = true) {
  const qc = useQueryClient();

  // Real-time subscription — instant dashboard updates on biller payments
  useEffect(() => {
    const channel = supabase
      .channel("rooms-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "rooms" },
        () => {
          qc.invalidateQueries({ queryKey: ["rooms"] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  return useQuery({
    queryKey: ["rooms"],
    queryFn: fetchRooms,
    placeholderData: getCachedRooms() ?? undefined,
    // Keep polling as fallback, but real-time handles instant updates
    refetchInterval: autoRefresh ? 60000 : false,
    staleTime: 10000,
  });
}
