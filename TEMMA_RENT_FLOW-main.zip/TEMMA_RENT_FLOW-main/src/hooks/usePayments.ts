import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Tables } from "@/integrations/supabase/types";
import { useEffect } from "react";
import { toast } from "sonner";
import { formatKES } from "@/lib/roomData";

export type Payment = Tables<"payments"> & { tenants?: Tables<"tenants"> | null; rooms?: Tables<"rooms"> | null };

export function usePayments() {
  const qc = useQueryClient();

  // Real-time subscription — instant updates when biller payments land
  useEffect(() => {
    const channel = supabase
      .channel("payments-realtime")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "payments" },
        async (payload) => {
          qc.invalidateQueries({ queryKey: ["payments"] });

          // Show toast with unit and amount for biller payments
          const record = payload.new as Tables<"payments">;
          const amount = Number(record.amount);

          // Look up room number
          const { data: room } = await supabase
            .from("rooms")
            .select("number")
            .eq("id", record.room_id)
            .single();

          const unit = room?.number ?? "Unknown";
          toast.success(`Payment received: ${formatKES(amount)}`, {
            description: `Unit ${unit} • ${record.payment_method ?? "equity_mtaani_pdq"}`,
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  return useQuery({
    queryKey: ["payments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("payments")
        .select("*, tenants(*), rooms(*)")
        .order("payment_date", { ascending: false })
        .limit(100);
      if (error) throw error;
      return data as Payment[];
    },
    refetchInterval: 60000,
  });
}

export function useRoomPayments(roomId: string | null) {
  const qc = useQueryClient();

  // Real-time for room-specific payments
  useEffect(() => {
    if (!roomId) return;
    const channel = supabase
      .channel(`payments-room-${roomId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "payments", filter: `room_id=eq.${roomId}` },
        () => {
          qc.invalidateQueries({ queryKey: ["payments", roomId] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [roomId, qc]);

  return useQuery({
    queryKey: ["payments", roomId],
    queryFn: async () => {
      if (!roomId) return [];
      const { data, error } = await supabase
        .from("payments")
        .select("id, amount, payment_date, payment_method, reference_number")
        .eq("room_id", roomId)
        .order("payment_date", { ascending: false })
        .limit(5);
      if (error) throw error;
      return data as Pick<Tables<"payments">, "id" | "amount" | "payment_date" | "payment_method" | "reference_number">[];
    },
    enabled: !!roomId,
    staleTime: 5000,
  });
}

export function useAuditLogs() {
  return useQuery({
    queryKey: ["audit_logs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("audit_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return data;
    },
    refetchInterval: 30000,
  });
}
