import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import { toast } from "sonner";

export type Tenant = Tables<"tenants">;

export function useTenants() {
  return useQuery({
    queryKey: ["tenants"],
    queryFn: async () => {
      const { data, error } = await supabase.from("tenants").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data as Tenant[];
    },
  });
}

export function useCreateTenant() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (tenant: TablesInsert<"tenants">) => {
      const { data, error } = await supabase.from("tenants").insert(tenant).select().single();
      if (error) throw error;
      // Audit log
      await supabase.from("audit_logs").insert({
        action: "tenant_created",
        entity_type: "tenant",
        entity_id: data.id,
        details: { full_name: data.full_name, id_number: data.id_number },
      });
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tenants"] });
      toast.success("Tenant onboarded successfully");
    },
    onError: (e) => toast.error(`Failed: ${e.message}`),
  });
}

export function useUpdateTenant() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: TablesUpdate<"tenants"> & { id: string }) => {
      const { data, error } = await supabase.from("tenants").update(updates).eq("id", id).select().single();
      if (error) throw error;
      await supabase.from("audit_logs").insert({
        action: "tenant_updated",
        entity_type: "tenant",
        entity_id: data.id,
        details: updates,
      });
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tenants"] });
      toast.success("Tenant updated");
    },
    onError: (e) => toast.error(`Failed: ${e.message}`),
  });
}
