import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export function useResetRentCycle() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      const now = new Date().toISOString();
      const base = { amount_paid: 0, aging_days: 0, status: "overdue" as const, updated_at: now };

      const [rooms, shops] = await Promise.all([
        supabase.from("rooms").update({ ...base, amount_due: 4500 }).neq("status", "vacant").eq("room_type", "room").select("id"),
        supabase.from("rooms").update({ ...base, amount_due: 7500 }).neq("status", "vacant").eq("room_type", "shop").select("id"),
      ]);

      if (rooms.error) throw rooms.error;
      if (shops.error) throw shops.error;

      return (rooms.data?.length ?? 0) + (shops.data?.length ?? 0);
    },
    onSuccess: (updatedCount) => {
      qc.invalidateQueries({ queryKey: ["rooms"] });
      toast.success(
        updatedCount > 0
          ? `Started new billing period for ${updatedCount} occupied room${updatedCount === 1 ? "" : "s"}`
          : "No occupied rooms found to reset",
      );
    },
    onError: (e: Error) => {
      toast.error(`Failed to reset billing period: ${e.message}`);
    },
  });
}
