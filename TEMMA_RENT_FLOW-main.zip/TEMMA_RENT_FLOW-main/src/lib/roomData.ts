export type RoomStatus = 'paid' | 'partial' | 'overdue' | 'advance' | 'exception' | 'vacant';

export interface Block {
  id: string;
  name: string;
  floors: number;
  roomsPerFloor: number;
}

export type RoomType = 'room' | 'shop';

export interface Room {
  id: string;
  number: string;
  block: string;
  floor: number;
  status: RoomStatus;
  roomType: RoomType;
  guest?: string;
  amountDue: number;
  amountPaid: number;
  checkIn?: string;
  checkOut?: string;
  agingDays: number;
}

const kenyanNames = [
  'W. Kamau', 'A. Wanjiku', 'J. Odhiambo', 'M. Muthoni', 'P. Kipchoge',
  'S. Akinyi', 'D. Njoroge', 'G. Chebet', 'F. Otieno', 'L. Wambui',
  'R. Kimani', 'E. Nyambura', 'B. Omondi', 'C. Mwangi', 'H. Cherono',
  'K. Nyong\'o', 'T. Muturi', 'N. Kosgei', 'I. Wafula', 'O. Auma',
  'V. Kiprono', 'U. Njeri', 'Q. Rotich', 'X. Adhiambo', 'Y. Kiplagat',
  'Z. Wairimu', 'A. Barasa', 'B. Chepkoech', 'C. Musyoka', 'D. Nyakio',
];

export const blocks: Block[] = [
  { id: 'A', name: 'Block A — Nyali', floors: 8, roomsPerFloor: 28 },
  { id: 'B', name: 'Block B — Kilimani', floors: 8, roomsPerFloor: 28 },
  { id: 'C', name: 'Block C — Westlands', floors: 8, roomsPerFloor: 28 },
  { id: 'D', name: 'Block D — Lavington', floors: 8, roomsPerFloor: 42 },
  { id: 'E', name: 'Block E — Karen', floors: 8, roomsPerFloor: 42 },
  { id: 'F', name: 'Block F — Muthaiga', floors: 8, roomsPerFloor: 28 },
  { id: 'G', name: 'Block G — Runda', floors: 8, roomsPerFloor: 28 },
  { id: 'H', name: 'Block H — Kileleshwa', floors: 7, roomsPerFloor: 9 },
  { id: 'J', name: 'Block J — Parklands', floors: 10, roomsPerFloor: 19 },
];

const statuses: RoomStatus[] = ['paid', 'partial', 'overdue', 'advance', 'exception', 'vacant'];
const weights = [30, 20, 15, 10, 5, 20];

function pickStatus(): RoomStatus {
  const r = Math.random() * 100;
  let cum = 0;
  for (let i = 0; i < statuses.length; i++) {
    cum += weights[i];
    if (r < cum) return statuses[i];
  }
  return 'vacant';
}

export function generateRooms(): Room[] {
  const rooms: Room[] = [];
  for (const block of blocks) {
    for (let floor = 1; floor <= block.floors; floor++) {
      for (let room = 1; room <= block.roomsPerFloor; room++) {
        const num = `${block.id}${floor}${String(room).padStart(2, '0')}`;
        const status = pickStatus();
        const isOccupied = status !== 'vacant';
        const amountDue = isOccupied ? Math.round((Math.random() * 80000 + 15000)) : 0;
        let amountPaid = 0;
        let agingDays = 0;

        switch (status) {
          case 'paid': amountPaid = amountDue; break;
          case 'partial': amountPaid = Math.round(amountDue * (0.3 + Math.random() * 0.4)); break;
          case 'overdue': amountPaid = Math.round(amountDue * Math.random() * 0.2); agingDays = Math.floor(Math.random() * 90) + 1; break;
          case 'advance': amountPaid = Math.round(amountDue * (1.1 + Math.random() * 0.5)); break;
          case 'exception': amountPaid = Math.round(amountDue * Math.random()); agingDays = Math.floor(Math.random() * 30); break;
        }

        const roomType: RoomType = floor === 1 ? 'shop' : 'room';
        rooms.push({
          id: `room-${num}`,
          number: num,
          block: block.id,
          floor,
          status,
          roomType,
          guest: isOccupied ? kenyanNames[Math.floor(Math.random() * kenyanNames.length)] : undefined,
          amountDue,
          amountPaid,
          agingDays,
          checkIn: isOccupied ? '2026-03-01' : undefined,
          checkOut: isOccupied ? '2026-03-10' : undefined,
        });
      }
    }
  }
  return rooms;
}

export const statusConfig: Record<RoomStatus, { label: string; emoji: string; colorClass: string; glowClass: string }> = {
  paid: { label: 'Fully Paid', emoji: '🟢', colorClass: 'bg-status-paid', glowClass: 'status-glow-green' },
  partial: { label: 'Partial Payment', emoji: '🟡', colorClass: 'bg-status-partial', glowClass: 'status-glow-yellow' },
  overdue: { label: 'Overdue', emoji: '🔴', colorClass: 'bg-status-overdue', glowClass: 'status-glow-red' },
  advance: { label: 'Advance Credit', emoji: '🔵', colorClass: 'bg-status-advance', glowClass: 'status-glow-blue' },
  exception: { label: 'Unmatched Exception', emoji: '🟣', colorClass: 'bg-status-exception', glowClass: 'status-glow-purple' },
  vacant: { label: 'Vacant', emoji: '⚫', colorClass: 'bg-status-vacant', glowClass: '' },
};

export function formatKES(amount: number): string {
  return `KES ${amount.toLocaleString()}`;
}

/**
 * Convert a room number (e.g. "RM A1", "RM 5") to its Equity Biller bill number.
 * Block A–G: "RM A1" → "RM-A1"
 * Block H:   "RM 5"  → "RM-H5"
 */
export function toBillNumber(roomNumber: string, block: string): string {
  const num = roomNumber.replace(/^RM\s*/, "");
  if (block === "H") {
    return `RM-H${num}`;
  }
  return `RM-${num}`;
}

export function getAgingBucket(days: number): string {
  if (days <= 30) return '0–30';
  if (days <= 60) return '30–60';
  return '60+';
}
