import { useState } from "react";
import { motion } from "framer-motion";
import { FileText, Plus } from "lucide-react";
import { useLeases, useCreateLease } from "@/hooks/useLeases";
import { useTenants } from "@/hooks/useTenants";
import { useRooms } from "@/hooks/useRooms";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";

const statusColors: Record<string, string> = {
  active: "bg-status-paid/20 text-status-paid border-status-paid/30",
  pending: "bg-status-partial/20 text-status-partial border-status-partial/30",
  expired: "bg-status-vacant/20 text-muted-foreground border-border",
  terminated: "bg-status-overdue/20 text-status-overdue border-status-overdue/30",
};

function formatKES(amount: number): string {
  return `KES ${amount.toLocaleString()}`;
}

export default function Leases() {
  const { data: leases = [], isLoading } = useLeases();
  const { data: tenants = [] } = useTenants();
  const { data: rooms = [] } = useRooms(false);
  const createLease = useCreateLease();
  const [addOpen, setAddOpen] = useState(false);
  const [tenantId, setTenantId] = useState("");
  const [roomId, setRoomId] = useState("");

  const handleCreate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    await createLease.mutateAsync({
      tenant_id: tenantId,
      room_id: roomId,
      start_date: fd.get("start_date") as string,
      end_date: fd.get("end_date") as string,
      monthly_rent: Number(fd.get("monthly_rent")),
      deposit_amount: Number(fd.get("deposit") || 0),
      status: "active",
    });
    setAddOpen(false);
  };

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
            <FileText className="h-5 w-5 text-accent-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">Lease Management</h1>
            <p className="text-xs text-muted-foreground font-mono">{leases.length} active leases</p>
          </div>
        </div>

        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1.5"><Plus className="h-4 w-4" /> New Lease</Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create Lease</DialogTitle>
              <DialogDescription>Assign a tenant to a room</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="space-y-2">
                <Label>Tenant *</Label>
                <Select value={tenantId} onValueChange={setTenantId}>
                  <SelectTrigger><SelectValue placeholder="Select tenant" /></SelectTrigger>
                  <SelectContent>
                    {tenants.map((t) => (
                      <SelectItem key={t.id} value={t.id}>{t.full_name} ({t.id_number})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Room *</Label>
                <Select value={roomId} onValueChange={setRoomId}>
                  <SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger>
                  <SelectContent>
                    {rooms.filter(r => r.status === 'vacant').map((r) => (
                      <SelectItem key={r.id} value={r.id}>Room {r.number}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="start_date">Start Date *</Label>
                  <Input id="start_date" name="start_date" type="date" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="end_date">End Date *</Label>
                  <Input id="end_date" name="end_date" type="date" required />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="monthly_rent">Monthly Rent (KES) *</Label>
                  <Input id="monthly_rent" name="monthly_rent" type="number" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="deposit">Deposit (KES)</Label>
                  <Input id="deposit" name="deposit" type="number" defaultValue={0} />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createLease.isPending || !tenantId || !roomId}>
                  {createLease.isPending ? "Creating..." : "Create Lease"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </motion.div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary/30">
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Tenant</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Room</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Rent</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Period</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Status</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">Loading...</td></tr>
              ) : leases.length === 0 ? (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">No leases yet</td></tr>
              ) : (
                leases.map((l) => (
                  <tr key={l.id} className="border-b border-border/50 hover:bg-secondary/20">
                    <td className="px-4 py-3 font-medium text-foreground">{l.tenants?.full_name || "—"}</td>
                    <td className="px-4 py-3 font-mono text-muted-foreground">{l.rooms?.number || "—"}</td>
                    <td className="px-4 py-3 font-mono text-foreground">{formatKES(l.monthly_rent)}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground font-mono">{l.start_date} → {l.end_date}</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className={statusColors[l.status]}>{l.status}</Badge>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
