import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import {
  BarChart3, TrendingUp, PieChart as PieIcon, Store, Home, Calendar,
  AlertTriangle, CheckCircle2, Building2, Users, Shield, Wallet
} from "lucide-react";
import { useRooms } from "@/hooks/useRooms";
import { useBlocks } from "@/hooks/useBlocks";
import { useMonthlyStatus } from "@/hooks/useMonthlyStatus";
import { MetricCard } from "@/components/MetricCard";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Area, AreaChart, Legend, RadarChart, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis, Radar
} from "recharts";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";

function formatKES(amount: number): string {
  return `KES ${amount.toLocaleString()}`;
}

const STATUS_COLORS: Record<string, string> = {
  paid: "hsl(var(--status-paid))",
  partial: "hsl(var(--status-partial))",
  overdue: "hsl(var(--status-overdue))",
  advance: "hsl(var(--status-advance))",
  exception: "hsl(var(--status-exception))",
  vacant: "hsl(var(--status-vacant))",
};

const STATUS_COLORS_FIXED: Record<string, string> = {
  paid: "hsl(142, 71%, 45%)",
  partial: "hsl(45, 93%, 47%)",
  overdue: "hsl(0, 72%, 51%)",
  advance: "hsl(210, 100%, 56%)",
  exception: "hsl(262, 83%, 58%)",
  vacant: "hsl(220, 13%, 30%)",
};

const ROOM_COLOR = "hsl(210, 100%, 56%)";
const SHOP_COLOR = "hsl(45, 93%, 47%)";

const chartTooltipStyle = {
  background: "hsl(222, 44%, 9%)",
  border: "1px solid hsl(222, 30%, 18%)",
  borderRadius: "8px",
  color: "hsl(210, 20%, 92%)",
};

const MONTH_OPTIONS = [
  { value: "2026-01-01", label: "January 2026" },
  { value: "2026-02-01", label: "February 2026" },
  { value: "2026-03-01", label: "March 2026" },
  { value: "2026-04-01", label: "April 2026" },
  { value: "2026-05-01", label: "May 2026" },
];

export default function Analytics() {
  const { data: dbRooms = [] } = useRooms();
  const { data: dbBlocks = [] } = useBlocks();
  const [selectedMonth, setSelectedMonth] = useState("2026-03-01");
  const [viewMode, setViewMode] = useState<string>("overview");

  const monthDate = useMemo(() => new Date(selectedMonth), [selectedMonth]);
  const { data: monthlyStatus = [] } = useMonthlyStatus(monthDate);

  const rooms = useMemo(() => dbRooms.map((r) => ({
    ...r,
    room_type: (r as any).room_type ?? (r.floor === 1 ? "shop" : "room") as "room" | "shop",
  })), [dbRooms]);

  // Apply monthly overlay if available
  const effectiveRooms = useMemo(() => {
    if (monthlyStatus.length === 0) return rooms;
    return rooms.map((r) => {
      const ms = monthlyStatus.find((m) => m.room_id === r.id);
      if (!ms) return r;
      return { ...r, amount_due: Number(ms.expected_rent), amount_paid: Number(ms.total_paid), status: ms.status as any };
    });
  }, [rooms, monthlyStatus]);

  const roomUnits = effectiveRooms.filter((r) => r.room_type === "room");
  const shopUnits = effectiveRooms.filter((r) => r.room_type === "shop");

  // Status distribution
  const statusData = Object.entries(
    effectiveRooms.reduce((acc, r) => { acc[r.status] = (acc[r.status] || 0) + 1; return acc; }, {} as Record<string, number>)
  ).map(([name, value]) => ({ name, value }));

  // Revenue by block
  const blockRevenueData = useMemo(() => {
    return dbBlocks.map((b) => {
      const bRooms = effectiveRooms.filter((r) => r.block_id === b.id);
      const billing = bRooms.reduce((s, r) => s + r.amount_due, 0);
      const paid = bRooms.reduce((s, r) => s + r.amount_paid, 0);
      const overdue = bRooms.filter((r) => r.status === "overdue").length;
      const collectionRate = billing > 0 ? Math.round((paid / billing) * 100) : 0;
      return { block: b.code, billing, paid, balance: billing - paid, overdue, collectionRate, total: bRooms.length };
    }).sort((a, b) => a.block.localeCompare(b.block));
  }, [dbBlocks, effectiveRooms]);

  // Radar data for block collection performance
  const radarData = blockRevenueData.map((b) => ({
    block: `Blk ${b.block}`,
    collection: b.collectionRate,
    occupancy: b.total > 0 ? Math.round(((b.total - effectiveRooms.filter(r => r.block_id === dbBlocks.find(bl => bl.code === b.block)?.id && r.status === "vacant").length) / b.total) * 100) : 0,
  }));

  // Shop vs Room comparison per block
  const shopRoomComparison = useMemo(() => {
    return dbBlocks.map((b) => {
      const bRooms = effectiveRooms.filter((r) => r.block_id === b.id);
      const shops = bRooms.filter((r) => r.room_type === "shop");
      const rms = bRooms.filter((r) => r.room_type === "room");
      return {
        block: b.code,
        shopRevenue: shops.reduce((s, r) => s + r.amount_paid, 0),
        roomRevenue: rms.reduce((s, r) => s + r.amount_paid, 0),
        shopCount: shops.length,
        roomCount: rms.length,
      };
    }).sort((a, b) => a.block.localeCompare(b.block));
  }, [dbBlocks, effectiveRooms]);

  // Vacancy analysis
  const vacancyData = useMemo(() => {
    return dbBlocks.map((b) => {
      const bRooms = effectiveRooms.filter((r) => r.block_id === b.id);
      const vacant = bRooms.filter((r) => r.status === "vacant").length;
      const lostRevenue = bRooms.filter(r => r.status === "vacant").length * 4500;
      return { block: b.code, total: bRooms.length, vacant, occupied: bRooms.length - vacant, lostRevenue };
    }).sort((a, b) => a.block.localeCompare(b.block));
  }, [dbBlocks, effectiveRooms]);

  // Deposit analysis
  const depositData = useMemo(() => {
    return dbBlocks.map((b) => {
      const bRooms = dbRooms.filter((r) => r.block_id === b.id);
      const expected = bRooms.reduce((s, r) => s + ((r as any).deposit_expected ?? 0), 0);
      const paid = bRooms.reduce((s, r) => s + ((r as any).deposit_paid ?? 0), 0);
      const fullyPaid = bRooms.filter((r) => {
        const exp = (r as any).deposit_expected ?? 0;
        const pd = (r as any).deposit_paid ?? 0;
        return exp > 0 && pd >= exp;
      }).length;
      const unpaid = bRooms.filter((r) => {
        const exp = (r as any).deposit_expected ?? 0;
        const pd = (r as any).deposit_paid ?? 0;
        return exp > 0 && pd === 0;
      }).length;
      const partial = bRooms.filter((r) => {
        const exp = (r as any).deposit_expected ?? 0;
        const pd = (r as any).deposit_paid ?? 0;
        return exp > 0 && pd > 0 && pd < exp;
      }).length;
      return { block: b.code, expected, paid, balance: expected - paid, fullyPaid, unpaid, partial, total: bRooms.length };
    }).sort((a, b) => a.block.localeCompare(b.block));
  }, [dbBlocks, dbRooms]);

  const totalDepositExpected = dbRooms.reduce((s, r) => s + ((r as any).deposit_expected ?? 0), 0);
  const totalDepositPaid = dbRooms.reduce((s, r) => s + ((r as any).deposit_paid ?? 0), 0);
  const depositFullyPaid = dbRooms.filter((r) => { const e = (r as any).deposit_expected ?? 0; const p = (r as any).deposit_paid ?? 0; return e > 0 && p >= e; }).length;
  const depositUnpaid = dbRooms.filter((r) => { const e = (r as any).deposit_expected ?? 0; const p = (r as any).deposit_paid ?? 0; return e > 0 && p === 0; }).length;
  const depositRate = totalDepositExpected > 0 ? Math.round((totalDepositPaid / totalDepositExpected) * 100) : 0;

  const depositStatusPie = [
    { name: "Paid", value: depositFullyPaid },
    { name: "Unpaid", value: depositUnpaid },
    { name: "Partial", value: dbRooms.filter((r) => { const e = (r as any).deposit_expected ?? 0; const p = (r as any).deposit_paid ?? 0; return e > 0 && p > 0 && p < e; }).length },
  ].filter(d => d.value > 0);

  const DEPOSIT_COLORS = ["hsl(142, 71%, 45%)", "hsl(0, 72%, 51%)", "hsl(45, 93%, 47%)"];

  // Floor occupancy across all blocks
  const floorData = useMemo(() => {
    const maxFloor = effectiveRooms.reduce((m, r) => Math.max(m, r.floor), 0);
    return Array.from({ length: maxFloor }, (_, i) => {
      const floor = i + 1;
      const floorRooms = effectiveRooms.filter((r) => r.floor === floor);
      const occupied = floorRooms.filter((r) => r.status !== "vacant").length;
      const revenue = floorRooms.reduce((s, r) => s + r.amount_paid, 0);
      return {
        floor: floor === 1 ? "GF" : `F${floor}`,
        total: floorRooms.length,
        occupied,
        vacant: floorRooms.length - occupied,
        rate: floorRooms.length ? Math.round((occupied / floorRooms.length) * 100) : 0,
        revenue,
      };
    });
  }, [effectiveRooms]);

  const totalRevenue = effectiveRooms.reduce((s, r) => s + r.amount_paid, 0);
  const totalBilling = effectiveRooms.reduce((s, r) => s + r.amount_due, 0);
  const occupancy = effectiveRooms.filter((r) => r.status !== "vacant").length;
  const overdueAmount = effectiveRooms.filter((r) => r.status === "overdue").reduce((s, r) => s + (r.amount_due - r.amount_paid), 0);
  const overdueCount = effectiveRooms.filter((r) => r.status === "overdue").length;
  const collectionRate = totalBilling > 0 ? Math.round((totalRevenue / totalBilling) * 100) : 0;
  const vacantCount = effectiveRooms.filter((r) => r.status === "vacant").length;

  const roomRevenue = roomUnits.reduce((s, r) => s + r.amount_paid, 0);
  const shopRevenue = shopUnits.reduce((s, r) => s + r.amount_paid, 0);
  const currentMonthLabel = MONTH_OPTIONS.find((m) => m.value === selectedMonth)?.label ?? "";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
            <BarChart3 className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">Analytics Dashboard</h1>
            <p className="text-xs text-muted-foreground font-mono">
              {roomUnits.length} Rooms · {shopUnits.length} Shops · {currentMonthLabel}
            </p>
          </div>
        </motion.div>

        <div className="flex items-center gap-2 flex-wrap">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[170px] h-8 text-xs">
              <Calendar className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MONTH_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value} className="text-xs">{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <ToggleGroup type="single" value={viewMode} onValueChange={(v) => v && setViewMode(v)} className="bg-secondary rounded-md p-0.5">
            <ToggleGroupItem value="overview" className="text-xs h-7 px-2.5 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">Overview</ToggleGroupItem>
            <ToggleGroupItem value="blocks" className="text-xs h-7 px-2.5 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">Blocks</ToggleGroupItem>
            <ToggleGroupItem value="deposits" className="text-xs h-7 px-2.5 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">Deposits</ToggleGroupItem>
            <ToggleGroupItem value="vacancy" className="text-xs h-7 px-2.5 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">Vacancy</ToggleGroupItem>
          </ToggleGroup>
        </div>
      </div>

      {/* KPIs */}
      {viewMode === "deposits" ? (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
          <MetricCard title="Total Deposits Expected" value={formatKES(totalDepositExpected)} icon={Shield} delay={0.05} />
          <MetricCard title="Deposits Collected" value={formatKES(totalDepositPaid)} subtitle={`${depositRate}% collected`} icon={Wallet} delay={0.1} />
          <MetricCard title="Deposit Balance" value={formatKES(totalDepositExpected - totalDepositPaid)} subtitle="outstanding" icon={AlertTriangle} trend={{ value: formatKES(totalDepositExpected - totalDepositPaid), positive: false }} delay={0.15} />
          <MetricCard title="Fully Paid" value={String(depositFullyPaid)} subtitle={`of ${depositFullyPaid + depositUnpaid + depositStatusPie.find(d=>d.name==="Partial")?.value!} units`} icon={CheckCircle2} delay={0.2} />
          <MetricCard title="Unpaid Deposits" value={String(depositUnpaid)} subtitle="units with no deposit" icon={Building2} delay={0.25} />
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <MetricCard title="Total Revenue" value={formatKES(totalRevenue)} icon={TrendingUp} delay={0.05} />
          <MetricCard title="Collection Rate" value={`${collectionRate}%`} subtitle={`${formatKES(totalBilling)} billed`} icon={CheckCircle2} delay={0.1} />
          <MetricCard title="Room Revenue" value={formatKES(roomRevenue)} subtitle={`${roomUnits.filter(r => r.status !== "vacant").length} occupied`} icon={Home} delay={0.15} />
          <MetricCard title="Shop Revenue" value={formatKES(shopRevenue)} subtitle={`${shopUnits.filter(r => r.status !== "vacant").length} occupied`} icon={Store} delay={0.2} />
          <MetricCard title="At Risk" value={formatKES(overdueAmount)} subtitle={`${overdueCount} overdue`} icon={AlertTriangle} trend={{ value: `${overdueCount}`, positive: false }} delay={0.25} />
          <MetricCard title="Vacant Units" value={String(vacantCount)} subtitle={`${effectiveRooms.length ? Math.round((occupancy / effectiveRooms.length) * 100) : 0}% occupied`} icon={Building2} delay={0.3} />
        </div>
      )}

      {/* Overview View */}
      {viewMode === "overview" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Status Distribution Pie */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Status Distribution</h3>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={statusData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                  {statusData.map((entry) => (
                    <Cell key={entry.name} fill={STATUS_COLORS_FIXED[entry.name] || "#666"} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => [value, "Units"]} contentStyle={chartTooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Rooms vs Shops Revenue Pie */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Rooms vs Shops Revenue</h3>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={[
                  { name: "Rooms", value: roomRevenue },
                  { name: "Shops", value: shopRevenue },
                ]} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                  <Cell fill={ROOM_COLOR} />
                  <Cell fill={SHOP_COLOR} />
                </Pie>
                <Tooltip formatter={(value: number, name: string) => [formatKES(value), `${name} Revenue`]} contentStyle={chartTooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-6 mt-2 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full" style={{ background: ROOM_COLOR }} /> Rooms: {formatKES(roomRevenue)}</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full" style={{ background: SHOP_COLOR }} /> Shops: {formatKES(shopRevenue)}</span>
            </div>
          </motion.div>

          {/* Floor Occupancy & Revenue */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Occupancy by Floor</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={floorData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 18%)" />
                <XAxis dataKey="floor" tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 10 }} />
                <YAxis tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} />
                <Tooltip contentStyle={chartTooltipStyle} />
                <Bar dataKey="occupied" fill="hsl(142, 71%, 45%)" radius={[4, 4, 0, 0]} name="Occupied" />
                <Bar dataKey="vacant" fill="hsl(0, 72%, 51%)" radius={[4, 4, 0, 0]} name="Vacant" />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Block Collection Radar */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Block Performance Radar</h3>
            <ResponsiveContainer width="100%" height={250}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="hsl(222, 30%, 18%)" />
                <PolarAngleAxis dataKey="block" tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 10 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 9 }} />
                <Radar name="Collection %" dataKey="collection" stroke="hsl(142, 71%, 45%)" fill="hsl(142, 71%, 45%)" fillOpacity={0.3} />
                <Radar name="Occupancy %" dataKey="occupancy" stroke="hsl(210, 100%, 56%)" fill="hsl(210, 100%, 56%)" fillOpacity={0.2} />
                <Legend />
                <Tooltip contentStyle={chartTooltipStyle} />
              </RadarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>
      )}

      {/* Blocks View */}
      {viewMode === "blocks" && (
        <div className="grid grid-cols-1 gap-4">
          {/* Revenue by Block */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Revenue & Collection by Block</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={blockRevenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 18%)" />
                <XAxis dataKey="block" tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} />
                <YAxis tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(value: number, name: string) => [formatKES(value), name === "paid" ? "Collected" : name === "billing" ? "Billed" : name]} contentStyle={chartTooltipStyle} />
                <Legend />
                <Bar dataKey="billing" fill="hsl(220, 13%, 40%)" radius={[0, 0, 0, 0]} name="Billed" />
                <Bar dataKey="paid" fill="hsl(142, 71%, 45%)" radius={[4, 4, 0, 0]} name="Collected" />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Shop vs Room Revenue by Block */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Shop vs Room Revenue by Block</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={shopRoomComparison}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 18%)" />
                <XAxis dataKey="block" tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} />
                <YAxis tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(value: number, name: string) => [formatKES(value), name === "shopRevenue" ? "Shop Revenue" : "Room Revenue"]} contentStyle={chartTooltipStyle} />
                <Legend formatter={(v) => v === "shopRevenue" ? "Shops" : "Rooms"} />
                <Bar dataKey="roomRevenue" stackId="a" fill={ROOM_COLOR} name="roomRevenue" />
                <Bar dataKey="shopRevenue" stackId="a" fill={SHOP_COLOR} radius={[4, 4, 0, 0]} name="shopRevenue" />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Block Collection Heatmap Table */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Block Summary Table</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 px-3 text-muted-foreground">Block</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Units</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Billed</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Collected</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Balance</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Overdue</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Collection %</th>
                  </tr>
                </thead>
                <tbody>
                  {blockRevenueData.map((b) => (
                    <tr key={b.block} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                      <td className="py-2 px-3 font-semibold text-foreground">Block {b.block}</td>
                      <td className="py-2 px-3 text-right text-foreground">{b.total}</td>
                      <td className="py-2 px-3 text-right text-foreground">{formatKES(b.billing)}</td>
                      <td className="py-2 px-3 text-right text-foreground">{formatKES(b.paid)}</td>
                      <td className="py-2 px-3 text-right text-destructive">{formatKES(b.balance)}</td>
                      <td className="py-2 px-3 text-right text-destructive">{b.overdue}</td>
                      <td className="py-2 px-3 text-right">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                          b.collectionRate >= 95 ? "bg-status-paid/20 text-green-400" :
                          b.collectionRate >= 80 ? "bg-status-partial/20 text-yellow-400" :
                          "bg-status-overdue/20 text-red-400"
                        }`}>
                          {b.collectionRate}%
                        </span>
                      </td>
                    </tr>
                  ))}
                  <tr className="font-semibold border-t-2 border-border">
                    <td className="py-2 px-3 text-foreground">TOTAL</td>
                    <td className="py-2 px-3 text-right text-foreground">{blockRevenueData.reduce((s, b) => s + b.total, 0)}</td>
                    <td className="py-2 px-3 text-right text-foreground">{formatKES(totalBilling)}</td>
                    <td className="py-2 px-3 text-right text-foreground">{formatKES(totalRevenue)}</td>
                    <td className="py-2 px-3 text-right text-destructive">{formatKES(totalBilling - totalRevenue)}</td>
                    <td className="py-2 px-3 text-right text-destructive">{overdueCount}</td>
                    <td className="py-2 px-3 text-right">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-status-paid/20 text-green-400">{collectionRate}%</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>
      )}

      {/* Deposits View */}
      {viewMode === "deposits" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Deposit Status Pie */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Deposit Status Distribution</h3>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={depositStatusPie} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                  {depositStatusPie.map((_, i) => (
                    <Cell key={i} fill={DEPOSIT_COLORS[i % DEPOSIT_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => [value, "Units"]} contentStyle={chartTooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-2 text-xs text-muted-foreground">
              {depositStatusPie.map((d, i) => (
                <span key={d.name} className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: DEPOSIT_COLORS[i] }} />
                  {d.name}: {d.value}
                </span>
              ))}
            </div>
          </motion.div>

          {/* Deposit Collection by Block */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Deposit Collection by Block</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={depositData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 18%)" />
                <XAxis dataKey="block" tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} />
                <YAxis tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(value: number, name: string) => [formatKES(value), name === "expected" ? "Expected" : "Collected"]} contentStyle={chartTooltipStyle} />
                <Legend formatter={(v) => v === "expected" ? "Expected" : "Collected"} />
                <Bar dataKey="expected" fill="hsl(220, 13%, 40%)" name="expected" />
                <Bar dataKey="paid" fill="hsl(142, 71%, 45%)" radius={[4, 4, 0, 0]} name="paid" />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Deposit Summary Table */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="rounded-lg border border-border bg-card p-5 lg:col-span-2">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Deposit Summary by Block</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 px-3 text-muted-foreground">Block</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Units</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Expected</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Collected</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Balance</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Fully Paid</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Unpaid</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {depositData.map((b) => {
                    const rate = b.expected > 0 ? Math.round((b.paid / b.expected) * 100) : 0;
                    return (
                      <tr key={b.block} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                        <td className="py-2 px-3 font-semibold text-foreground">Block {b.block}</td>
                        <td className="py-2 px-3 text-right text-foreground">{b.total}</td>
                        <td className="py-2 px-3 text-right text-foreground">{formatKES(b.expected)}</td>
                        <td className="py-2 px-3 text-right text-foreground">{formatKES(b.paid)}</td>
                        <td className="py-2 px-3 text-right text-destructive">{formatKES(b.balance)}</td>
                        <td className="py-2 px-3 text-right text-foreground">{b.fullyPaid}</td>
                        <td className="py-2 px-3 text-right text-destructive">{b.unpaid}</td>
                        <td className="py-2 px-3 text-right">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                            rate >= 95 ? "bg-status-paid/20 text-green-400" :
                            rate >= 50 ? "bg-status-partial/20 text-yellow-400" :
                            "bg-status-overdue/20 text-red-400"
                          }`}>{rate}%</span>
                        </td>
                      </tr>
                    );
                  })}
                  <tr className="font-semibold border-t-2 border-border">
                    <td className="py-2 px-3 text-foreground">TOTAL</td>
                    <td className="py-2 px-3 text-right text-foreground">{depositData.reduce((s, b) => s + b.total, 0)}</td>
                    <td className="py-2 px-3 text-right text-foreground">{formatKES(totalDepositExpected)}</td>
                    <td className="py-2 px-3 text-right text-foreground">{formatKES(totalDepositPaid)}</td>
                    <td className="py-2 px-3 text-right text-destructive">{formatKES(totalDepositExpected - totalDepositPaid)}</td>
                    <td className="py-2 px-3 text-right text-foreground">{depositFullyPaid}</td>
                    <td className="py-2 px-3 text-right text-destructive">{depositUnpaid}</td>
                    <td className="py-2 px-3 text-right">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-primary/20 text-primary">{depositRate}%</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>
      )}

      {/* Vacancy View */}
      {viewMode === "vacancy" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Vacancy by Block */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Vacancy by Block</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={vacancyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 18%)" />
                <XAxis dataKey="block" tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} />
                <YAxis tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} />
                <Tooltip contentStyle={chartTooltipStyle} />
                <Legend />
                <Bar dataKey="occupied" stackId="a" fill="hsl(142, 71%, 45%)" name="Occupied" />
                <Bar dataKey="vacant" stackId="a" fill="hsl(0, 72%, 51%)" radius={[4, 4, 0, 0]} name="Vacant" />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Vacancy Impact Table */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-lg border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Vacancy Impact Analysis</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 px-3 text-muted-foreground">Block</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Total</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Vacant</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Vacancy %</th>
                    <th className="text-right py-2 px-3 text-muted-foreground">Occupancy %</th>
                  </tr>
                </thead>
                <tbody>
                  {vacancyData.map((b) => (
                    <tr key={b.block} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                      <td className="py-2 px-3 font-semibold text-foreground">Block {b.block}</td>
                      <td className="py-2 px-3 text-right text-foreground">{b.total}</td>
                      <td className="py-2 px-3 text-right text-destructive">{b.vacant}</td>
                      <td className="py-2 px-3 text-right text-destructive">{b.total ? Math.round((b.vacant / b.total) * 100) : 0}%</td>
                      <td className="py-2 px-3 text-right">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                          b.total && ((b.occupied / b.total) * 100) >= 95 ? "bg-status-paid/20 text-green-400" :
                          "bg-status-partial/20 text-yellow-400"
                        }`}>
                          {b.total ? Math.round((b.occupied / b.total) * 100) : 0}%
                        </span>
                      </td>
                    </tr>
                  ))}
                  <tr className="font-semibold border-t-2 border-border">
                    <td className="py-2 px-3 text-foreground">TOTAL</td>
                    <td className="py-2 px-3 text-right text-foreground">{vacancyData.reduce((s, b) => s + b.total, 0)}</td>
                    <td className="py-2 px-3 text-right text-destructive">{vacantCount}</td>
                    <td className="py-2 px-3 text-right text-destructive">{effectiveRooms.length ? Math.round((vacantCount / effectiveRooms.length) * 100) : 0}%</td>
                    <td className="py-2 px-3 text-right">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-status-paid/20 text-green-400">
                        {effectiveRooms.length ? Math.round((occupancy / effectiveRooms.length) * 100) : 0}%
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>

          {/* Status breakdown for overdue rooms */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="rounded-lg border border-border bg-card p-5 lg:col-span-2">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Revenue by Status (Rooms vs Shops)</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={(() => {
                const statuses = ["paid", "partial", "overdue", "advance", "exception", "vacant"];
                return statuses.map((status) => ({
                  status,
                  rooms: roomUnits.filter((r) => r.status === status).reduce((s, r) => s + r.amount_paid, 0),
                  shops: shopUnits.filter((r) => r.status === status).reduce((s, r) => s + r.amount_paid, 0),
                }));
              })()}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 18%)" />
                <XAxis dataKey="status" tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} />
                <YAxis tick={{ fill: "hsl(215, 15%, 52%)", fontSize: 11 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(value: number, name: string) => [formatKES(value), name === "rooms" ? "Rooms" : "Shops"]} contentStyle={chartTooltipStyle} />
                <Legend formatter={(value) => (value === "rooms" ? "Rooms" : "Shops")} />
                <Bar dataKey="rooms" stackId="a" fill={ROOM_COLOR} />
                <Bar dataKey="shops" stackId="a" fill={SHOP_COLOR} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>
      )}
    </div>
  );
}
