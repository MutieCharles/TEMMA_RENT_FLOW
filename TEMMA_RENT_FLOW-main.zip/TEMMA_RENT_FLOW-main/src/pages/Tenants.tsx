import { useState } from "react";
import { motion } from "framer-motion";
import { Users, Plus, Search, CheckCircle, Clock, XCircle, Eye } from "lucide-react";
import { useTenants, useCreateTenant, useUpdateTenant, Tenant } from "@/hooks/useTenants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const kycIcons = {
  pending: <Clock className="h-3 w-3" />,
  verified: <CheckCircle className="h-3 w-3" />,
  rejected: <XCircle className="h-3 w-3" />,
};

const kycColors: Record<string, string> = {
  pending: "bg-status-partial/20 text-status-partial border-status-partial/30",
  verified: "bg-status-paid/20 text-status-paid border-status-paid/30",
  rejected: "bg-status-overdue/20 text-status-overdue border-status-overdue/30",
};

export default function Tenants() {
  const { data: tenants = [], isLoading } = useTenants();
  const createTenant = useCreateTenant();
  const updateTenant = useUpdateTenant();
  const [search, setSearch] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [viewTenant, setViewTenant] = useState<Tenant | null>(null);

  const filtered = tenants.filter(
    (t) =>
      t.full_name.toLowerCase().includes(search.toLowerCase()) ||
      t.id_number.includes(search) ||
      t.phone.includes(search)
  );

  const handleCreate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    await createTenant.mutateAsync({
      full_name: fd.get("full_name") as string,
      id_number: fd.get("id_number") as string,
      phone: fd.get("phone") as string,
      email: (fd.get("email") as string) || null,
      emergency_contact_name: (fd.get("emergency_name") as string) || null,
      emergency_contact_phone: (fd.get("emergency_phone") as string) || null,
    });
    setAddOpen(false);
  };

  const handleKycUpdate = async (tenant: Tenant, status: "pending" | "verified" | "rejected", notes?: string) => {
    await updateTenant.mutateAsync({
      id: tenant.id,
      kyc_status: status,
      kyc_notes: notes || null,
      kyc_verified_at: status === "verified" ? new Date().toISOString() : null,
    });
    setViewTenant(null);
  };

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
            <Users className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">Tenant Management</h1>
            <p className="text-xs text-muted-foreground font-mono">{tenants.length} tenants · KYC Verification</p>
          </div>
        </div>

        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1.5">
              <Plus className="h-4 w-4" /> Onboard Tenant
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Onboard New Tenant</DialogTitle>
              <DialogDescription>Enter tenant details for KYC verification</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="full_name">Full Name *</Label>
                <Input id="full_name" name="full_name" required placeholder="e.g. John Kamau" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="id_number">ID Number *</Label>
                  <Input id="id_number" name="id_number" required placeholder="e.g. 12345678" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone *</Label>
                  <Input id="phone" name="phone" required placeholder="+254..." />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" name="email" type="email" placeholder="optional" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="emergency_name">Emergency Contact</Label>
                  <Input id="emergency_name" name="emergency_name" placeholder="Name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emergency_phone">Emergency Phone</Label>
                  <Input id="emergency_phone" name="emergency_phone" placeholder="+254..." />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createTenant.isPending}>
                  {createTenant.isPending ? "Saving..." : "Onboard Tenant"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </motion.div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="Search by name, ID, or phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Table */}
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary/30">
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Name</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">ID No.</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Phone</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">KYC</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Joined</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">Loading...</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No tenants found</td></tr>
              ) : (
                filtered.map((t) => (
                  <tr key={t.id} className="border-b border-border/50 hover:bg-secondary/20">
                    <td className="px-4 py-3 font-medium text-foreground">{t.full_name}</td>
                    <td className="px-4 py-3 font-mono text-muted-foreground">{t.id_number}</td>
                    <td className="px-4 py-3 font-mono text-muted-foreground">{t.phone}</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className={`gap-1 ${kycColors[t.kyc_status]}`}>
                        {kycIcons[t.kyc_status]}
                        {t.kyc_status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground font-mono">
                      {new Date(t.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3">
                      <Button variant="ghost" size="sm" onClick={() => setViewTenant(t)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* View / KYC Dialog */}
      <Dialog open={!!viewTenant} onOpenChange={() => setViewTenant(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tenant Details</DialogTitle>
            <DialogDescription>View and manage KYC verification</DialogDescription>
          </DialogHeader>
          {viewTenant && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-muted-foreground">Name:</span> <span className="font-medium text-foreground">{viewTenant.full_name}</span></div>
                <div><span className="text-muted-foreground">ID:</span> <span className="font-mono text-foreground">{viewTenant.id_number}</span></div>
                <div><span className="text-muted-foreground">Phone:</span> <span className="font-mono text-foreground">{viewTenant.phone}</span></div>
                <div><span className="text-muted-foreground">Email:</span> <span className="font-mono text-foreground">{viewTenant.email || "—"}</span></div>
                <div><span className="text-muted-foreground">Emergency:</span> <span className="text-foreground">{viewTenant.emergency_contact_name || "—"} {viewTenant.emergency_contact_phone || ""}</span></div>
                <div>
                  <span className="text-muted-foreground">KYC:</span>{" "}
                  <Badge variant="outline" className={`gap-1 ${kycColors[viewTenant.kyc_status]}`}>
                    {kycIcons[viewTenant.kyc_status]} {viewTenant.kyc_status}
                  </Badge>
                </div>
              </div>
              {viewTenant.kyc_notes && (
                <div className="text-sm"><span className="text-muted-foreground">KYC Notes:</span> <span className="text-foreground">{viewTenant.kyc_notes}</span></div>
              )}
              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="border-status-paid/30 text-status-paid hover:bg-status-paid/10"
                  onClick={() => handleKycUpdate(viewTenant, "verified")}
                  disabled={updateTenant.isPending}
                >
                  <CheckCircle className="h-3 w-3 mr-1" /> Verify KYC
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-status-overdue/30 text-status-overdue hover:bg-status-overdue/10"
                  onClick={() => handleKycUpdate(viewTenant, "rejected", "Requires additional documentation")}
                  disabled={updateTenant.isPending}
                >
                  <XCircle className="h-3 w-3 mr-1" /> Reject
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
