import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import {
  format,
  startOfMonth,
  addMonths,
  subMonths,
  isSameMonth,
  isAfter,
} from "date-fns";
import {
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  Loader2,
  Grid3X3,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useRooms, DbRoom } from "@/hooks/useRooms";
import { useBlocks } from "@/hooks/useBlocks";
import { useMonthlyStatus } from "@/hooks/useMonthlyStatus";
import { statusConfig, formatKES, RoomStatus, toBillNumber } from "@/lib/roomData";

type CellStatus = RoomStatus | "future" | "no-data";

const cellColors: Record<CellStatus, string> = {
  paid: "bg-status-paid",
  partial: "bg-status-partial",
  overdue: "bg-status-overdue",
  advance: "bg-status-advance",
  exception: "bg-status-exception",
  vacant: "bg-status-vacant",
  future: "bg-muted",
  "no-data": "bg-muted/50",
};

const cellLabels: Record<CellStatus, string> = {
  ...Object.fromEntries(
    Object.entries(statusConfig).map(([k, v]) => [k, v.label])
  ),
  future: "Future",
  "no-data": "No Data",
} as Record<CellStatus, string>;

export default function Matrix() {
  const [selectedMonth, setSelectedMonth] = useState(() => startOfMonth(new Date()));
  const { data: dbRooms, isLoading: roomsLoading } = useRooms(false);
  const { data: dbBlocks } = useBlocks();
  const { data: summaryRows, isLoading: summaryLoading } = useMonthlyStatus(selectedMonth);

  const now = startOfMonth(new Date());
  const isCurrentMonth = isSameMonth(selectedMonth, now);
  const isFutureMonth = isAfter(selectedMonth, now);

  // Build visible months range: selected ± 3
  const visibleMonths = useMemo(() => {
    const months: Date[] = [];
    for (let i = -3; i <= 3; i++) {
      months.push(addMonths(selectedMonth, i));
    }
    return months;
  }, [selectedMonth]);

  // Group rooms by block
  const blockGroups = useMemo(() => {
    const blocks = (dbBlocks ?? []).sort((a, b) => a.code.localeCompare(b.code));
    const rooms = dbRooms ?? [];
    return blocks.map((block) => ({
      block,
      rooms: rooms
        .filter((r) => r.block_id === block.id)
        .sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true })),
    }));
  }, [dbRooms, dbBlocks]);

  // Map summary rows by room_id for quick lookup
  const summaryByRoom = useMemo(() => {
    const map = new Map<string, typeof summaryRows extends (infer T)[] ? T : never>();
    for (const row of summaryRows ?? []) {
      map.set(row.room_id, row);
    }
    return map;
  }, [summaryRows]);

  // Determine cell status for a room in the selected month
  function getCellStatus(room: DbRoom): { status: CellStatus; paid: number; due: number } {
    if (isFutureMonth) {
      return { status: "future", paid: 0, due: 0 };
    }

    if (isCurrentMonth) {
      // Live data from room
      const st = room.status as RoomStatus;
      return {
        status: st,
        paid: Number(room.amount_paid),
        due: Number(room.amount_due),
      };
    }

    // Past month — use snapshot
    const snap = summaryByRoom.get(room.id);
    if (!snap) {
      return { status: "no-data", paid: 0, due: 0 };
    }
    return {
      status: snap.status as CellStatus,
      paid: Number(snap.total_paid),
      due: Number(snap.expected_rent),
    };
  }

  const isLoading = roomsLoading || summaryLoading;

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
            <Grid3X3 className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              Monthly Status Matrix
            </h1>
            <p className="text-xs text-muted-foreground font-mono">
              Billing period navigation · Color-coded reconciliation
            </p>
          </div>
        </div>

        {/* Month navigation */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8"
            onClick={() => setSelectedMonth((m) => subMonths(m, 1))}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant={isCurrentMonth ? "default" : "outline"}
            className="h-8 px-3 text-xs font-mono min-w-[120px]"
            onClick={() => setSelectedMonth(now)}
          >
            <CalendarDays className="h-3.5 w-3.5 mr-1.5" />
            {format(selectedMonth, "MMM yyyy")}
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8"
            onClick={() => setSelectedMonth((m) => addMonths(m, 1))}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </motion.div>

      {/* Month tabs */}
      <div className="flex gap-1 overflow-x-auto pb-1">
        {visibleMonths.map((m) => {
          const active = isSameMonth(m, selectedMonth);
          const future = isAfter(m, now);
          return (
            <button
              key={m.toISOString()}
              onClick={() => setSelectedMonth(startOfMonth(m))}
              className={`px-3 py-1.5 rounded-md text-xs font-mono whitespace-nowrap transition-colors ${
                active
                  ? "bg-primary text-primary-foreground"
                  : future
                  ? "bg-muted/50 text-muted-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              {format(m, "MMM yy")}
              {isSameMonth(m, now) && (
                <span className="ml-1 text-[9px] opacity-70">●</span>
              )}
            </button>
          );
        })}
      </div>

      {isLoading && (
        <div className="flex items-center justify-center h-32">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      )}

      {!isLoading && isFutureMonth && (
        <div className="rounded-lg border border-border bg-card p-8 text-center">
          <CalendarDays className="h-8 w-8 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">
            No billing data for future months
          </p>
        </div>
      )}

      {/* Matrix grid per block */}
      {!isLoading &&
        !isFutureMonth &&
        blockGroups.map(({ block, rooms }, groupIdx) => (
          <motion.div
            key={block.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.5,
              delay: groupIdx * 0.06,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="rounded-lg border border-border bg-card p-4"
          >
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              Block {block.code} — {rooms.length} units
            </h3>
            <div className="flex flex-wrap gap-1">
              {rooms.map((room) => {
                const { status, paid, due } = getCellStatus(room);
                const colorClass = cellColors[status] ?? "bg-muted";
                const label = cellLabels[status] ?? status;
                const billNumber = toBillNumber(
                  room.number,
                  block.code
                );
                const shortNum = room.number
                  .replace(/^RM\s*[A-H]?/, "")
                  .slice(-3);

                return (
                  <Tooltip key={room.id}>
                    <TooltipTrigger asChild>
                      <div
                        className={`w-7 h-7 rounded text-[9px] font-mono font-semibold flex items-center justify-center ${colorClass} ${
                          status === "vacant" || status === "future" || status === "no-data"
                            ? "text-muted-foreground"
                            : "text-primary-foreground"
                        }`}
                      >
                        {shortNum}
                      </div>
                    </TooltipTrigger>
                    <TooltipContent className="bg-card border-border text-foreground p-3 space-y-1 min-w-[140px]">
                      <p className="font-mono font-semibold text-xs">
                        {billNumber}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {label}
                      </p>
                      {due > 0 && (
                        <>
                          <div className="flex justify-between text-[11px]">
                            <span className="text-muted-foreground">Due</span>
                            <span>{formatKES(due)}</span>
                          </div>
                          <div className="flex justify-between text-[11px]">
                            <span className="text-muted-foreground">Paid</span>
                            <span>{formatKES(paid)}</span>
                          </div>
                        </>
                      )}
                    </TooltipContent>
                  </Tooltip>
                );
              })}
            </div>
          </motion.div>
        ))}

      {/* Legend */}
      <div className="flex flex-wrap gap-3 pt-2">
        {Object.entries(statusConfig).map(([key, cfg]) => (
          <div key={key} className="flex items-center gap-1.5">
            <div className={`w-3 h-3 rounded-sm ${cfg.colorClass}`} />
            <span className="text-xs text-muted-foreground">{cfg.label}</span>
          </div>
        ))}
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-sm bg-muted" />
          <span className="text-xs text-muted-foreground">Future</span>
        </div>
      </div>
    </div>
  );
}
