import { motion } from "framer-motion";
import { Shield, Activity } from "lucide-react";
import { useAuditLogs } from "@/hooks/usePayments";
import { Badge } from "@/components/ui/badge";

const actionColors: Record<string, string> = {
  tenant_created: "bg-status-paid/20 text-status-paid border-status-paid/30",
  tenant_updated: "bg-status-advance/20 text-status-advance border-status-advance/30",
  lease_created: "bg-status-partial/20 text-status-partial border-status-partial/30",
  payment_received: "bg-status-paid/20 text-status-paid border-status-paid/30",
  kyc_updated: "bg-accent/20 text-accent border-accent/30",
};

export default function Audit() {
  const { data: logs = [], isLoading } = useAuditLogs();

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-status-exception flex items-center justify-center">
          <Shield className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-foreground">Audit Trail</h1>
          <p className="text-xs text-muted-foreground font-mono">Complete activity logging · Auto-refresh 30s</p>
        </div>
      </motion.div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary/30">
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Time</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Action</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Entity</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Details</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={4} className="px-4 py-8 text-center text-muted-foreground">Loading...</td></tr>
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-12 text-center">
                    <Activity className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No audit events yet. Actions will appear here automatically.</p>
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="border-b border-border/50 hover:bg-secondary/20">
                    <td className="px-4 py-3 text-xs font-mono text-muted-foreground whitespace-nowrap">
                      {new Date(log.created_at).toLocaleString()}
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className={actionColors[log.action] || "bg-secondary text-muted-foreground border-border"}>
                        {log.action.replace(/_/g, " ")}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 font-mono text-muted-foreground text-xs">
                      {log.entity_type} {log.entity_id ? `(${log.entity_id.slice(0, 8)}...)` : ""}
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground max-w-xs truncate">
                      {log.details ? JSON.stringify(log.details) : "—"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
