import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { format, parseISO } from "date-fns";
import {
  CreditCard, Filter, X, ChevronLeft, ChevronRight,
  CheckCircle2, Circle, Loader2, Banknote, CalendarIcon,
} from "lucide-react";
import { usePaymentsTable, PaymentsFilter, PAYMENT_METHODS, PAGE_SIZE } from "@/hooks/usePaymentsTable";
import { useBlocks } from "@/hooks/useBlocks";
import { formatKES } from "@/lib/roomData";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";

const METHOD_LABELS: Record<string, string> = {
  equity_mtaani_pdq: "Equity Mtaani-PDQ",
  cash: "Cash",
  mpesa: "M-Pesa",
  bank_transfer: "Bank Transfer",
  cheque: "Cheque",
};

const METHOD_COLORS: Record<string, string> = {
  equity_mtaani_pdq: "bg-primary/10 text-primary border-primary/20",
  cash: "bg-status-paid/10 text-status-paid border-status-paid/20",
  mpesa: "bg-primary/10 text-primary border-primary/20",
  bank_transfer: "bg-status-advance/10 text-status-advance border-status-advance/20",
  cheque: "bg-muted text-muted-foreground border-border",
};

type ReconciledFilter = "all" | "reconciled" | "unreconciled";

export default function Payments() {
  const { data: blocks = [] } = useBlocks();

  const [blockId, setBlockId] = useState<string | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null);
  const [dateFrom, setDateFrom] = useState<Date | undefined>(undefined);
  const [dateTo, setDateTo] = useState<Date | undefined>(undefined);
  const [reconciled, setReconciled] = useState<ReconciledFilter>("all");
  const [page, setPage] = useState(1);

  const filter: PaymentsFilter = {
    blockId,
    paymentMethod,
    dateFrom: dateFrom ? format(dateFrom, "yyyy-MM-dd") : null,
    dateTo: dateTo ? format(dateTo, "yyyy-MM-dd") : null,
    reconciled,
    page,
    pageSize: PAGE_SIZE,
  };

  const { data, isLoading } = usePaymentsTable(filter);
  const payments = data?.data ?? [];
  const totalCount = data?.count ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));

  const clearFilters = useCallback(() => {
    setBlockId(null);
    setPaymentMethod(null);
    setDateFrom(undefined);
    setDateTo(undefined);
    setReconciled("all");
    setPage(1);
  }, []);

  const hasActiveFilters = blockId || paymentMethod || dateFrom || dateTo || reconciled !== "all";

  const resetPage = () => setPage(1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
          <CreditCard className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-foreground tracking-tight">Payments</h1>
          <p className="text-xs text-muted-foreground font-mono">{totalCount} total records</p>
        </div>
      </motion.div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="flex flex-wrap gap-2 items-center p-3 rounded-xl border border-border bg-card"
      >
        <Filter className="h-4 w-4 text-muted-foreground shrink-0" />

        {/* Block filter */}
        <Select
          value={blockId ?? "all"}
          onValueChange={(v) => { setBlockId(v === "all" ? null : v); resetPage(); }}
        >
          <SelectTrigger className="h-8 w-36 text-xs">
            <SelectValue placeholder="All Blocks" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Blocks</SelectItem>
            {blocks.map((b) => (
              <SelectItem key={b.id} value={b.id}>{b.name} ({b.code})</SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Method filter */}
        <Select
          value={paymentMethod ?? "all"}
          onValueChange={(v) => { setPaymentMethod(v === "all" ? null : v); resetPage(); }}
        >
          <SelectTrigger className="h-8 w-36 text-xs">
            <SelectValue placeholder="All Methods" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Methods</SelectItem>
            {PAYMENT_METHODS.map((m) => (
              <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Date From */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className={cn("h-8 text-xs font-normal gap-1.5", !dateFrom && "text-muted-foreground")}>
              <CalendarIcon className="h-3.5 w-3.5" />
              {dateFrom ? format(dateFrom, "dd MMM yyyy") : "From date"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={dateFrom}
              onSelect={(d) => { setDateFrom(d); resetPage(); }}
              initialFocus
              className="p-3 pointer-events-auto"
            />
          </PopoverContent>
        </Popover>

        {/* Date To */}
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className={cn("h-8 text-xs font-normal gap-1.5", !dateTo && "text-muted-foreground")}>
              <CalendarIcon className="h-3.5 w-3.5" />
              {dateTo ? format(dateTo, "dd MMM yyyy") : "To date"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={dateTo}
              onSelect={(d) => { setDateTo(d); resetPage(); }}
              initialFocus
              className="p-3 pointer-events-auto"
            />
          </PopoverContent>
        </Popover>

        {/* Reconciled toggle */}
        <div className="flex rounded-lg border border-border overflow-hidden text-xs">
          {(["all", "reconciled", "unreconciled"] as ReconciledFilter[]).map((v) => (
            <button
              key={v}
              onClick={() => { setReconciled(v); resetPage(); }}
              className={cn(
                "px-3 py-1.5 capitalize transition-colors",
                reconciled === v
                  ? "bg-primary text-primary-foreground font-medium"
                  : "text-muted-foreground hover:bg-muted",
              )}
            >
              {v === "all" ? "All" : v === "reconciled" ? "Reconciled" : "Unreconciled"}
            </button>
          ))}
        </div>

        {hasActiveFilters && (
          <Button variant="ghost" size="sm" className="h-8 text-xs gap-1 text-muted-foreground" onClick={clearFilters}>
            <X className="h-3.5 w-3.5" /> Clear
          </Button>
        )}
      </motion.div>

      {/* Table */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="rounded-xl border border-border bg-card overflow-hidden"
      >
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-xs font-semibold text-muted-foreground w-36">Date</TableHead>
              <TableHead className="text-xs font-semibold text-muted-foreground">Room</TableHead>
              <TableHead className="text-xs font-semibold text-muted-foreground">Tenant</TableHead>
              <TableHead className="text-xs font-semibold text-muted-foreground">Method</TableHead>
              <TableHead className="text-xs font-semibold text-muted-foreground">Reference</TableHead>
              <TableHead className="text-xs font-semibold text-muted-foreground text-right">Amount</TableHead>
              <TableHead className="text-xs font-semibold text-muted-foreground text-center w-28">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="h-40 text-center">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground mx-auto" />
                </TableCell>
              </TableRow>
            ) : payments.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-40 text-center">
                  <div className="flex flex-col items-center gap-2">
                    <Banknote className="h-8 w-8 text-muted-foreground/40" />
                    <p className="text-sm text-muted-foreground">No payments found</p>
                    {hasActiveFilters && (
                      <Button variant="link" size="sm" className="text-xs" onClick={clearFilters}>Clear filters</Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              payments.map((p) => {
                const block = p.rooms?.blocks;
                const roomLabel = block
                  ? `${block.code}-${p.rooms?.number}`
                  : p.rooms?.number ?? "—";
                const method = p.payment_method ?? "—";
                return (
                  <TableRow key={p.id} className="border-border">
                    <TableCell className="text-xs font-mono text-muted-foreground">
                      {format(parseISO(p.payment_date), "dd MMM yyyy")}
                      <div className="text-[10px] opacity-60">{format(parseISO(p.payment_date), "HH:mm")}</div>
                    </TableCell>
                    <TableCell>
                      <span className="text-xs font-mono font-semibold text-foreground">{roomLabel}</span>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground max-w-[140px] truncate">
                      {p.tenants?.full_name ?? "—"}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={cn("text-[11px] capitalize", METHOD_COLORS[method] ?? METHOD_COLORS.cheque)}
                      >
                        {METHOD_LABELS[method] ?? method}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs font-mono text-muted-foreground">
                      {p.reference_number ?? <span className="opacity-40">—</span>}
                    </TableCell>
                    <TableCell className="text-right">
                      <span className="text-sm font-bold text-foreground font-mono">{formatKES(Number(p.amount))}</span>
                    </TableCell>
                    <TableCell className="text-center">
                      {p.reconciled ? (
                        <div className="flex items-center justify-center gap-1 text-status-paid">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span className="text-[11px] font-medium">Reconciled</span>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center gap-1 text-muted-foreground">
                          <Circle className="h-3.5 w-3.5" />
                          <span className="text-[11px]">Pending</span>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </motion.div>

      {/* Pagination */}
      {totalPages > 1 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.15 }}
          className="flex items-center justify-between text-xs text-muted-foreground"
        >
          <span>
            Showing {Math.min((page - 1) * PAGE_SIZE + 1, totalCount)}–{Math.min(page * PAGE_SIZE, totalCount)} of {totalCount}
          </span>
          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon"
              className="h-7 w-7"
              disabled={page <= 1}
              onClick={() => setPage((p) => p - 1)}
            >
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>
            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
              const p = totalPages <= 7 ? i + 1 : page <= 4 ? i + 1 : page >= totalPages - 3 ? totalPages - 6 + i : page - 3 + i;
              return (
                <Button
                  key={p}
                  variant={p === page ? "default" : "outline"}
                  size="icon"
                  className="h-7 w-7 text-xs"
                  onClick={() => setPage(p)}
                >
                  {p}
                </Button>
              );
            })}
            <Button
              variant="outline"
              size="icon"
              className="h-7 w-7"
              disabled={page >= totalPages}
              onClick={() => setPage((p) => p + 1)}
            >
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
