import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { DollarSign, AlertTriangle, Building2, Shield, Loader2, RefreshCw, Home, Store, Calendar } from "lucide-react";
import { Room, formatKES, RoomStatus, RoomType } from "@/lib/roomData";
import { MetricCard } from "@/components/MetricCard";
import { RoomGrid } from "@/components/RoomGrid";
import { RoomDetail } from "@/components/RoomDetail";
import { AgingTable } from "@/components/AgingTable";
import { StatusBreakdown } from "@/components/StatusBreakdown";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useRooms, DbRoom } from "@/hooks/useRooms";
import { useBlocks } from "@/hooks/useBlocks";
import { useCloseMonth } from "@/hooks/useCloseMonth";
import { useMonthlyStatus, MonthlyStatusRow } from "@/hooks/useMonthlyStatus";

const MONTH_OPTIONS = [
  { value: "2026-01-01", label: "January 2026" },
  { value: "2026-02-01", label: "February 2026" },
  { value: "2026-03-01", label: "March 2026" },
  { value: "2026-04-01", label: "April 2026" },
  { value: "2026-05-01", label: "May 2026" },
];

function mapDbRoomToRoom(r: DbRoom): Room {
  return {
    id: r.id,
    number: r.number,
    block: r.blocks?.code ?? "",
    floor: r.floor,
    status: r.status as RoomStatus,
    roomType: ((r as any).room_type as RoomType) ?? (r.floor === 1 ? "shop" : "room"),
    amountDue: Number(r.amount_due),
    amountPaid: Number(r.amount_paid),
    agingDays: r.aging_days,
  };
}

function applyMonthlyOverlay(room: Room, mss: MonthlyStatusRow[]): Room {
  const match = mss.find((m) => m.room_id === room.id);
  if (!match) return room;
  return {
    ...room,
    amountDue: Number(match.expected_rent),
    amountPaid: Number(match.total_paid),
    status: match.status as RoomStatus,
  };
}

const Index = () => {
  const { data: dbRooms, isLoading } = useRooms();
  const { data: dbBlocks } = useBlocks();
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [unitFilter, setUnitFilter] = useState<string>("all");
  const [selectedMonth, setSelectedMonth] = useState<string>("2026-03-01");
  const closeMonth = useCloseMonth();

  const monthDate = useMemo(() => new Date(selectedMonth), [selectedMonth]);
  const { data: monthlyStatus } = useMonthlyStatus(monthDate);

  const allRooms = useMemo(() => {
    const base = (dbRooms ?? []).map(mapDbRoomToRoom);
    if (!monthlyStatus || monthlyStatus.length === 0) return base;
    return base.map((r) => applyMonthlyOverlay(r, monthlyStatus));
  }, [dbRooms, monthlyStatus]);

  const rooms = useMemo(() => {
    if (unitFilter === "room") return allRooms.filter((r) => r.roomType === "room");
    if (unitFilter === "shop") return allRooms.filter((r) => r.roomType === "shop");
    return allRooms;
  }, [allRooms, unitFilter]);

  const totalRevenue = rooms.reduce((s, r) => s + r.amountPaid, 0);
  const occupancy = rooms.filter((r) => r.status !== "vacant").length;
  const overdueCount = rooms.filter((r) => r.status === "overdue").length;
  const reconciled = rooms.filter((r) => r.status === "paid" || r.status === "advance").length;

  const currentMonthLabel = MONTH_OPTIONS.find((m) => m.value === selectedMonth)?.label ?? "";

  if (isLoading && rooms.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
            <Building2 className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">TEMMA Room Financial Intelligence</h1>
            <p className="text-xs text-muted-foreground font-mono">
              {dbBlocks?.length ?? 8} Blocks · {rooms.length} Rooms · {currentMonthLabel}
            </p>
          </div>
        </motion.div>

        <div className="flex items-center gap-2 flex-wrap">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[160px] h-8 text-xs">
              <Calendar className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MONTH_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value} className="text-xs">
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <ToggleGroup type="single" value={unitFilter} onValueChange={(v) => v && setUnitFilter(v)} className="bg-secondary rounded-md p-0.5">
            <ToggleGroupItem value="all" className="text-xs h-7 px-2.5 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">
              <Building2 className="h-3.5 w-3.5 mr-1" /> All
            </ToggleGroupItem>
            <ToggleGroupItem value="room" className="text-xs h-7 px-2.5 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">
              <Home className="h-3.5 w-3.5 mr-1" /> Rooms
            </ToggleGroupItem>
            <ToggleGroupItem value="shop" className="text-xs h-7 px-2.5 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">
              <Store className="h-3.5 w-3.5 mr-1" /> Shops
            </ToggleGroupItem>
          </ToggleGroup>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" disabled={closeMonth.isPending || occupancy === 0}>
                {closeMonth.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
                Close Month
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Close current billing period?</AlertDialogTitle>
                <AlertDialogDescription>
                  This snapshots all room statuses, carries forward advance credits, and starts a new billing period.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel disabled={closeMonth.isPending}>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => closeMonth.mutate()} disabled={closeMonth.isPending}>
                  {closeMonth.isPending ? "Closing..." : "Confirm close"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <MetricCard title="Total Revenue" value={formatKES(totalRevenue)} icon={DollarSign} trend={{ value: "12.4%", positive: true }} delay={0.05} />
        <MetricCard title="Occupancy" value={`${occupancy ? Math.round((occupancy / rooms.length) * 100) : 0}%`} subtitle={`${occupancy}/${rooms.length} rooms`} icon={Building2} delay={0.1} />
        <MetricCard title="Overdue Alerts" value={String(overdueCount)} subtitle={`${formatKES(rooms.filter((r) => r.status === "overdue").reduce((s, r) => s + r.amountDue - r.amountPaid, 0))} at risk`} icon={AlertTriangle} trend={{ value: `${overdueCount}`, positive: false }} delay={0.15} />
        <MetricCard title="Reconciled" value={`${occupancy ? Math.round((reconciled / occupancy) * 100) : 0}%`} subtitle={`${reconciled} rooms cleared`} icon={Shield} trend={{ value: "3.2%", positive: true }} delay={0.2} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <RoomGrid rooms={rooms} selectedRoom={selectedRoom} onSelect={setSelectedRoom} />
          <AgingTable rooms={rooms} />
        </div>
        <div className="space-y-4">
          <RoomDetail room={selectedRoom} />
          <StatusBreakdown rooms={rooms} />
        </div>
      </div>
    </div>
  );
};

export default Index;
