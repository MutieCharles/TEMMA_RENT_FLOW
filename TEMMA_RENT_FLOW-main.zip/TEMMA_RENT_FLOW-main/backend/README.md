# Structure of the Backend Directory

- backend/
  - main.py  # FastAPI application
  - requirements.txt  # Required packages
  - .env.template  # Environment variables template
  - modules/
    - equity_bank_biller/
      - __init__.py  # Package initialization
      - api_integration.py  # API integration and payment validation
      - webhook_handler.py  # Webhook notification handlers
    - google_sheets_integration/
      - __init__.py  # Package initialization
      - sheets_handler.py  # Functions for interacting with Google Sheets
