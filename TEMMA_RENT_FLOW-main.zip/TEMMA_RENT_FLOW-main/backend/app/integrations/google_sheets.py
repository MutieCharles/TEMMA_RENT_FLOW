"""Google Sheets Integration Module for RentFlow"""

from fastapi import APIRouter
from gspread import service_account

router = APIRouter()

@router.post("/sync-payments")
async def sync_payments():
    return {"message": "Payments synced successfully"}

@router.post("/import-payments")
async def import_payments():
    return {"message": "Payments imported successfully"}

@router.post("/reconcile")
async def reconcile():
    return {"message": "Reconciliation done successfully"}

@router.get("/status")
async def status_check():
    return {"status": "Service is up and running"}