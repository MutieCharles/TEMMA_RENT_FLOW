import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

/**
 * Parse "RM-A1" → room number in DB format.
 * Blocks A–G: "RM A1" .. "RM G234"
 * Block H:    "RM 1"  .. "RM 74"
 */
function billToRoomNumber(bill: string): string | null {
  const match = bill.match(/^RM-([A-H])(\d+)$/i);
  if (!match) return null;
  const block = match[1].toUpperCase();
  const unit = match[2];
  return block === "H" ? `RM ${unit}` : `RM ${block}${unit}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { billNumber, amount, bankReference, transactionDate } = await req.json();

    if (!billNumber || !amount || !bankReference) {
      return new Response(
        JSON.stringify({ responseCode: "400", responseMessage: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const roomNumber = billToRoomNumber(billNumber);
    if (!roomNumber) {
      return new Response(
        JSON.stringify({ responseCode: "400", responseMessage: "Invalid billNumber format" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    // Find room by number directly
    const { data: room, error: roomErr } = await supabase
      .from("rooms")
      .select("id, amount_due, amount_paid, status")
      .eq("number", roomNumber)
      .maybeSingle();

    if (roomErr) throw roomErr;
    if (!room) {
      return new Response(
        JSON.stringify({ responseCode: "404", responseMessage: `Unit ${billNumber} not found` }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Find active lease
    const { data: lease } = await supabase
      .from("leases")
      .select("id, tenant_id")
      .eq("room_id", room.id)
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!lease) {
      return new Response(
        JSON.stringify({ responseCode: "404", responseMessage: "No active lease for this unit" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const paymentAmount = Number(amount);
    const newAmountPaid = Number(room.amount_paid) + paymentAmount;
    const amountDue = Number(room.amount_due);

    // Determine new status
    let newStatus: string;
    if (newAmountPaid >= amountDue) {
      newStatus = newAmountPaid > amountDue ? "advance" : "paid";
    } else if (newAmountPaid > 0) {
      newStatus = "partial";
    } else {
      newStatus = "overdue";
    }

    // Parse transaction date
    const paymentDate = transactionDate
      ? new Date(transactionDate).toISOString()
      : new Date().toISOString();

    // Insert payment record
    const { data: payment, error: payErr } = await supabase
      .from("payments")
      .insert({
        room_id: room.id,
        lease_id: lease.id,
        tenant_id: lease.tenant_id,
        amount: paymentAmount,
        payment_method: "equity_mtaani_pdq",
        reference_number: bankReference,
        payment_date: paymentDate,
        reconciled: true,
      })
      .select("id")
      .single();

    if (payErr) throw payErr;

    // Update room
    const { error: updateErr } = await supabase
      .from("rooms")
      .update({
        amount_paid: newAmountPaid,
        status: newStatus,
        aging_days: newAmountPaid >= amountDue ? 0 : undefined,
      })
      .eq("id", room.id);

    if (updateErr) throw updateErr;

    // Audit log
    await supabase.from("audit_logs").insert({
      action: "biller_payment_received",
      entity_type: "payment",
      entity_id: payment.id,
      details: {
        bill_number: billNumber,
        amount: paymentAmount,
        bank_reference: bankReference,
        new_status: newStatus,
      },
    });

    return new Response(
      JSON.stringify({ responseCode: "200", responseMessage: "Success" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Notification error:", err);
    return new Response(
      JSON.stringify({ responseCode: "500", responseMessage: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
