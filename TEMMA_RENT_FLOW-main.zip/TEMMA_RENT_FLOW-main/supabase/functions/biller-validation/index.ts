import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

/**
 * Parse "RM-A1" → room number in DB format.
 * Blocks A–G: "RM A1" .. "RM G234"
 * Block H:    "RM 1"  .. "RM 74"
 */
function billToRoomNumber(bill: string): string | null {
  const match = bill.match(/^RM-([A-H])(\d+)$/i);
  if (!match) return null;
  const block = match[1].toUpperCase();
  const unit = match[2];
  return block === "H" ? `RM ${unit}` : `RM ${block}${unit}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { billNumber, amount } = await req.json();

    if (!billNumber || !amount) {
      return new Response(
        JSON.stringify({ description: "Missing billNumber or amount" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const roomNumber = billToRoomNumber(billNumber);
    if (!roomNumber) {
      return new Response(
        JSON.stringify({ description: "Invalid billNumber format. Expected RM-{Block}{Unit}, e.g. RM-A1" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    // Find room by its number directly
    const { data: room, error: roomErr } = await supabase
      .from("rooms")
      .select("id, number, amount_due, amount_paid, status")
      .eq("number", roomNumber)
      .maybeSingle();

    if (roomErr) throw roomErr;
    if (!room) {
      return new Response(
        JSON.stringify({ description: `Unit ${billNumber} not found` }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Find active lease + tenant
    const { data: lease } = await supabase
      .from("leases")
      .select("id, tenant_id, monthly_rent")
      .eq("room_id", room.id)
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    let customerName = "Vacant";
    if (lease) {
      const { data: tenant } = await supabase
        .from("tenants")
        .select("full_name")
        .eq("id", lease.tenant_id)
        .single();
      if (tenant) customerName = tenant.full_name;
    }

    const amountDue = Number(room.amount_due);
    const amountPaid = Number(room.amount_paid);
    const balance = Math.max(0, amountDue - amountPaid);

    return new Response(
      JSON.stringify({
        customerName,
        billNumber,
        amount: String(balance),
        description: "Success",
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Validation error:", err);
    return new Response(
      JSON.stringify({ description: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
