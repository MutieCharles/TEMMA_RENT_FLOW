
-- Monthly status snapshot table for billing period history
CREATE TABLE public.monthly_status_summary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  month date NOT NULL,
  expected_rent numeric NOT NULL DEFAULT 0,
  total_paid numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'overdue',
  advance_credit_carried_forward numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (room_id, month)
);

-- Enable RLS
ALTER TABLE public.monthly_status_summary ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Authenticated users can read monthly_status_summary"
  ON public.monthly_status_summary FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert monthly_status_summary"
  ON public.monthly_status_summary FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update monthly_status_summary"
  ON public.monthly_status_summary FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Public can read monthly_status_summary"
  ON public.monthly_status_summary FOR SELECT TO anon USING (true);

-- Indexes
CREATE INDEX idx_monthly_status_room_month ON public.monthly_status_summary(room_id, month);
CREATE INDEX idx_monthly_status_month ON public.monthly_status_summary(month);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.monthly_status_summary;
