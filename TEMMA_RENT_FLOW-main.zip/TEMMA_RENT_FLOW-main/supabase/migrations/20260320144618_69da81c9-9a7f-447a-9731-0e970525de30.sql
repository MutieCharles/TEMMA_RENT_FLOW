
CREATE POLICY "Public can insert monthly_status_summary"
  ON public.monthly_status_summary FOR INSERT
  TO anon WITH CHECK (true);

CREATE POLICY "Public can update monthly_status_summary"
  ON public.monthly_status_summary FOR UPDATE
  TO anon USING (true);
