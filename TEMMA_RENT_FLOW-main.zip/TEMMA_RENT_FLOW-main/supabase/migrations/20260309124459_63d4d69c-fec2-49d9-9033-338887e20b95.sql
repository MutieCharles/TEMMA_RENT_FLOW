CREATE POLICY "Public can read payments"
ON public.payments
FOR SELECT
TO anon
USING (true);

CREATE POLICY "Public can read tenants"
ON public.tenants
FOR SELECT
TO anon
USING (true);