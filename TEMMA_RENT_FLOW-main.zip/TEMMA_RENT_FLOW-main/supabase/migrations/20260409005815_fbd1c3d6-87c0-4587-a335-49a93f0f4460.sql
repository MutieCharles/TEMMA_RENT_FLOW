ALTER TABLE public.rooms ADD COLUMN deposit_paid numeric NOT NULL DEFAULT 0;

-- Also add deposit_expected for flexible deposit amounts per room
ALTER TABLE public.rooms ADD COLUMN deposit_expected numeric NOT NULL DEFAULT 0;