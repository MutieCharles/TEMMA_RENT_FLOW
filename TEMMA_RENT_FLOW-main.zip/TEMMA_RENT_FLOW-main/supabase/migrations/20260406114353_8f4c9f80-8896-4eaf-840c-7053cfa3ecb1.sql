CREATE OR REPLACE FUNCTION public.bulk_update_rooms(p_data jsonb)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated_count integer := 0;
  room_item jsonb;
BEGIN
  FOR room_item IN SELECT * FROM jsonb_array_elements(p_data)
  LOOP
    UPDATE rooms 
    SET 
      amount_due = (room_item->>'amount_due')::numeric,
      amount_paid = (room_item->>'amount_paid')::numeric,
      status = (room_item->>'status')::payment_status,
      room_type = (room_item->>'room_type')::room_type,
      floor = (room_item->>'floor')::integer
    WHERE number = room_item->>'number' 
      AND block_id = (room_item->>'block_id')::uuid;
    updated_count := updated_count + 1;
  END LOOP;
  RETURN updated_count;
END;
$$;