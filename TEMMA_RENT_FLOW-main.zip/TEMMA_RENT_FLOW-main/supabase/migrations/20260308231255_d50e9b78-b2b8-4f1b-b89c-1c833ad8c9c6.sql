
-- Allow anonymous read access to rooms and blocks for dashboard
CREATE POLICY "Public can read blocks" ON public.blocks FOR SELECT TO anon USING (true);
CREATE POLICY "Public can read rooms" ON public.rooms FOR SELECT TO anon USING (true);
