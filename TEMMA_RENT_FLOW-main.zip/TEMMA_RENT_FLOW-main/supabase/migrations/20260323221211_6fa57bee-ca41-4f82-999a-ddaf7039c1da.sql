
-- Reset all rooms to 'room' type first
UPDATE rooms SET room_type = 'room' WHERE room_type = 'shop';

-- Block A shops: 1-9, 13, 15
UPDATE rooms SET room_type = 'shop' WHERE number IN ('RM A1','RM A2','RM A3','RM A4','RM A5','RM A6','RM A7','RM A8','RM A9','RM A13','RM A15');

-- Block B shops: 1-10, 23, 49, 50
UPDATE rooms SET room_type = 'shop' WHERE number IN ('RM B1','RM B2','RM B3','RM B4','RM B5','RM B6','RM B7','RM B8','RM B9','RM B10','RM B23','RM B49','RM B50');

-- Block C shops: 1-8, 10, 11, 14
UPDATE rooms SET room_type = 'shop' WHERE number IN ('RM C1','RM C2','RM C3','RM C4','RM C5','RM C6','RM C7','RM C8','RM C10','RM C11','RM C14');

-- Block D shops: 1-14, 16-19, 37, 43, 44, 46, 47, 49, 50, 52, 53, 55, 57
UPDATE rooms SET room_type = 'shop' WHERE number IN ('RM D1','RM D2','RM D3','RM D4','RM D5','RM D6','RM D7','RM D8','RM D9','RM D10','RM D11','RM D12','RM D13','RM D14','RM D16','RM D17','RM D18','RM D19','RM D37','RM D43','RM D44','RM D46','RM D47','RM D49','RM D50','RM D52','RM D53','RM D55','RM D57');

-- Block E shops: 1-19, 35, 43, 44, 46, 47, 49
UPDATE rooms SET room_type = 'shop' WHERE number IN ('RM E1','RM E2','RM E3','RM E4','RM E5','RM E6','RM E7','RM E8','RM E9','RM E10','RM E11','RM E12','RM E13','RM E14','RM E15','RM E16','RM E17','RM E18','RM E19','RM E35','RM E43','RM E44','RM E46','RM E47','RM E49');

-- Block F shops: 1-4, 28
UPDATE rooms SET room_type = 'shop' WHERE number IN ('RM F1','RM F2','RM F3','RM F4','RM F28');

-- Block G shops: 1-12, 14, 16, 31, 34
UPDATE rooms SET room_type = 'shop' WHERE number IN ('RM G1','RM G2','RM G3','RM G4','RM G5','RM G6','RM G7','RM G8','RM G9','RM G10','RM G11','RM G12','RM G14','RM G16','RM G31','RM G34');

-- Block H shops: 1-3
UPDATE rooms SET room_type = 'shop' WHERE number IN ('RM 1','RM 2','RM 3');
