
-- Create room_type enum
CREATE TYPE public.room_type AS ENUM ('room', 'shop');

-- Add room_type column with default 'room'
ALTER TABLE public.rooms ADD COLUMN room_type public.room_type NOT NULL DEFAULT 'room';

-- Set ground floor (floor = 1) as shops
UPDATE public.rooms SET room_type = 'shop' WHERE floor = 1;

-- Update amount_due: rooms = 4500, shops = 7500
UPDATE public.rooms SET amount_due = 4500 WHERE room_type = 'room' AND status != 'vacant';
UPDATE public.rooms SET amount_due = 7500 WHERE room_type = 'shop' AND status != 'vacant';
