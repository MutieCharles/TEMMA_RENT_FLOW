
-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- KYC status enum
CREATE TYPE public.kyc_status AS ENUM ('pending', 'verified', 'rejected');

-- Lease status enum
CREATE TYPE public.lease_status AS ENUM ('active', 'expired', 'terminated', 'pending');

-- Payment status enum
CREATE TYPE public.payment_status AS ENUM ('paid', 'partial', 'overdue', 'advance', 'exception', 'vacant');

-- Room type enum
CREATE TYPE public.room_type AS ENUM ('room', 'shop');

-- Blocks table
CREATE TABLE public.blocks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  floors INTEGER NOT NULL DEFAULT 8,
  rooms_per_floor INTEGER NOT NULL DEFAULT 30,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Rooms table
CREATE TABLE public.rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  block_id UUID NOT NULL REFERENCES public.blocks(id) ON DELETE CASCADE,
  floor INTEGER NOT NULL,
  status payment_status NOT NULL DEFAULT 'vacant',
  room_type room_type NOT NULL DEFAULT 'room',
  amount_due NUMERIC NOT NULL DEFAULT 0,
  amount_paid NUMERIC NOT NULL DEFAULT 0,
  aging_days INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tenants table with KYC
CREATE TABLE public.tenants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name TEXT NOT NULL,
  id_number TEXT NOT NULL UNIQUE,
  phone TEXT NOT NULL,
  email TEXT,
  kyc_status kyc_status NOT NULL DEFAULT 'pending',
  kyc_notes TEXT,
  kyc_verified_at TIMESTAMPTZ,
  emergency_contact_name TEXT,
  emergency_contact_phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Leases table
CREATE TABLE public.leases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  monthly_rent NUMERIC NOT NULL,
  deposit_amount NUMERIC NOT NULL DEFAULT 0,
  status lease_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Payments table
CREATE TABLE public.payments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  lease_id UUID NOT NULL REFERENCES public.leases(id) ON DELETE CASCADE,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  payment_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  payment_method TEXT,
  reference_number TEXT,
  reconciled BOOLEAN NOT NULL DEFAULT false,
  hmac_signature TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Audit trail
CREATE TABLE public.audit_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  details JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Monthly status snapshot table
CREATE TABLE public.monthly_status_summary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  month date NOT NULL,
  expected_rent numeric NOT NULL DEFAULT 0,
  total_paid numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'overdue',
  advance_credit_carried_forward numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (room_id, month)
);

-- Enable RLS on all tables
ALTER TABLE public.blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monthly_status_summary ENABLE ROW LEVEL SECURITY;

-- Read policies (anon + authenticated)
CREATE POLICY "Public can read blocks" ON public.blocks FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Public can read rooms" ON public.rooms FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Public can read tenants" ON public.tenants FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Public can read leases" ON public.leases FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Public can read payments" ON public.payments FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Public can read audit_logs" ON public.audit_logs FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Public can read monthly_status_summary" ON public.monthly_status_summary FOR SELECT TO anon, authenticated USING (true);

-- Write policies
CREATE POLICY "Authenticated users can insert tenants" ON public.tenants FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update tenants" ON public.tenants FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert leases" ON public.leases FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update leases" ON public.leases FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert payments" ON public.payments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update rooms" ON public.rooms FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert audit_logs" ON public.audit_logs FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can insert blocks" ON public.blocks FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can insert rooms" ON public.rooms FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can insert monthly_status_summary" ON public.monthly_status_summary FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update monthly_status_summary" ON public.monthly_status_summary FOR UPDATE TO authenticated USING (true);

-- Anon write policies for dashboard operations
CREATE POLICY "Anon can insert audit_logs" ON public.audit_logs FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Anon can update rooms" ON public.rooms FOR UPDATE TO anon USING (true);
CREATE POLICY "Anon can insert payments" ON public.payments FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Anon can insert monthly_status_summary" ON public.monthly_status_summary FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Anon can update monthly_status_summary" ON public.monthly_status_summary FOR UPDATE TO anon USING (true);

-- Indexes
CREATE INDEX idx_rooms_block ON public.rooms(block_id);
CREATE INDEX idx_rooms_status ON public.rooms(status);
CREATE INDEX idx_leases_tenant ON public.leases(tenant_id);
CREATE INDEX idx_leases_room ON public.leases(room_id);
CREATE INDEX idx_payments_lease ON public.payments(lease_id);
CREATE INDEX idx_payments_tenant ON public.payments(tenant_id);
CREATE INDEX idx_audit_logs_entity ON public.audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_created ON public.audit_logs(created_at DESC);
CREATE INDEX idx_monthly_status_room_month ON public.monthly_status_summary(room_id, month);
CREATE INDEX idx_monthly_status_month ON public.monthly_status_summary(month);

-- Triggers
CREATE TRIGGER update_rooms_updated_at BEFORE UPDATE ON public.rooms FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_leases_updated_at BEFORE UPDATE ON public.leases FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.rooms;
ALTER PUBLICATION supabase_realtime ADD TABLE public.payments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.monthly_status_summary;
