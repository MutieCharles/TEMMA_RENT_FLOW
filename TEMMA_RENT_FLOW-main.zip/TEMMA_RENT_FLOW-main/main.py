# Main Application Entry Point

if __name__ == '__main__':
    print("Welcome to TEMMA RENT FLOW Backend!")
