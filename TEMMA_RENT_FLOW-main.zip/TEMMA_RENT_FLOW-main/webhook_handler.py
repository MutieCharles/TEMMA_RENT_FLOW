# Webhook Handler for Equity Bank Events

from flask import Flask, request

app = Flask(__name__)

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    # Process the webhook data
    return {'status': 'success'}, 200

if __name__ == '__main__':
    app.run(port=5000)
