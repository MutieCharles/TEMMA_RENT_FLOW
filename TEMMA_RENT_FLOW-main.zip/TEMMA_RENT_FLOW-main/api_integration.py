# Equity Bank Biller API Integration

import requests

class EquityBankBiller:
    def __init__(self, api_key, api_url):
        self.api_key = api_key
        self.api_url = api_url

    def make_payment(self, payment_data):
        response = requests.post(self.api_url, json=payment_data, headers={'Authorization': f'Bearer {self.api_key}'})
        return response.json()
